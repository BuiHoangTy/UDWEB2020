//đổi sang định dạng tiền
function number_format( number, decimals, dec_point, thousands_sep ) {
    var n = number, c = isNaN(decimals = Math.abs(decimals)) ? 2 : decimals;
    var d = dec_point == undefined ? "," : dec_point;
    var t = thousands_sep == undefined ? "." : thousands_sep, s = n < 0 ? "-" : "";
    var i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
}
//sử dụng Ajax cho addtocart
function addtocart(addid,addgia){
	 var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {

    	// readyState có 5 trạng thái: 4 là kết thúc request
    	// status = 200 là thành công, 404 là lỗi.
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("cart").innerHTML = this.responseText;
        }
    };

    if (document.getElementById("quantity") == null) {
        xmlhttp.open("POST", "controllers/index.php?addid=" + addid + "&addgia=" + addgia, true);
    } else{
        xmlhttp.open("POST", "controllers/index.php?addid=" + addid + "&addgia=" + addgia  + "&addsl=" + document.getElementById("quantity").value, true);

    }
    xmlhttp.send();
}

//trừ sản phẩm đi 1
function Tru(truid,trugia){
    var sl = 'sl'+truid;
    var tong = 'tong'+truid;
   if(document.getElementById(sl) != null && document.getElementById(sl).value > 1){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById(sl).value = Number(document.getElementById(sl).value) - 1;
                document.getElementById(tong).value = number_format(Number(document.getElementById(sl).value) * trugia,0,'.','.') + ' VNĐ';
                var t = Number(this.responseText);
                document.getElementById('suma').value = number_format(t,0,'.','.') + ' VNĐ';
            }
        };
        xmlhttp.open("POST", "controllers/index.php?truid=" + truid + "&trugia=" + trugia, true);
        xmlhttp.send();
   }
}

// cộng sản phẩm thêm 1
function Cong(congid,conggia){
    var sl = 'sl'+congid;
    var tong = 'tong'+congid;
   if(document.getElementById(sl) != null){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById(sl).value = Number(document.getElementById(sl).value) + 1;
                document.getElementById(tong).value = number_format(Number(document.getElementById(sl).value) * conggia,0,'.','.') + ' VNĐ';
                var t = Number(this.responseText);
                document.getElementById('suma').value = number_format(t,0,'.','.') + ' VNĐ';
            }
        };
        xmlhttp.open("POST", "controllers/index.php?congid=" + congid + "&conggia=" + conggia, true);
        xmlhttp.send();
   }
}


//người dùng thay đổi giá trị
function Doi(doiid,doigia){
    var sl = 'sl'+doiid;
    var tong = 'tong'+doiid;
   if(document.getElementById(sl) != null){
    console.log('ok');
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var t = Number(this.responseText);
                console.log(t);
                document.getElementById(tong).value = number_format(Number(document.getElementById(sl).value) * doigia,0,'.','.') + " VNĐ";
                document.getElementById('suma').value = number_format(t,0,'.','.') + ' VNĐ';
            }
        };
        var tmp = document.getElementById(sl).value;
        console.log(tmp);
        xmlhttp.open("POST", "controllers/index.php?doiid=" + doiid + "&doigia=" + doigia + "&doisl=" + tmp, true);
        xmlhttp.send();
   }
}


// tính phí ship
function ship(){
    var t = document.getElementById('shipping').value;
    if(t != ''){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("ship").innerHTML = number_format(Number(this.responseText),0,'.','.') + " VNĐ";
            }
        };

        xmlhttp.open("POST", "controllers/index.php?ship=" + t, true);
        xmlhttp.send();
    }

}


//tìm kiếm sản phẩm
function search_product(){
    str = document.getElementById("str_search").value;
    console.log( document.getElementById("str_search").value);
    if(str!=""){
        console.log('ok');
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200){
                document.getElementById("res_search").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("POST", "controllers/index.php?search_str=" + str, true);
        xmlhttp.send();
    }

}




$('.addcart').click(function(){
  var parent =$(this).parents('.pro');
  var cart =$(document).find('.shopping-item');
  var source= parent.find('img').attr('src');
  var paTop = parent.offset().top;
  var paLeft = parent.offset().left;
  $('<img/>', {
    src : source,
    class: 'img-fly'
}).appendTo('body').css({
  'top': paTop,
  'left': parseInt(paLeft)+ parseInt(parent.width())-50
});
  setTimeout(function(){
  $('.img-fly').css({
    'top': cart.offset().top,
    'left': parseInt(cart.offset().left)+ parseInt(cart.width())
  });
  setTimeout(function(){
    $('.img-fly').remove();
    var amount = parseInt(cart.find('#procount').data('count'))+1;
    cart.find('#procount').text(amount).data('count',amount);
  },1000);
  },500);

});


(function() {
  var movecart = $('.shopping-item').offset().top;
  $(window).scroll(function(event) {

    var posbody = $(window).scrollTop();
    if (posbody >= posmenu) {

     $('.shopping-item').addClass('shopping-item2');
    }
     else {
      $('.shopping-item').removeClass('shopping-item2');
    }



  });
});
