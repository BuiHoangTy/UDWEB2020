<?php
	function connect(){
		$conn = mysqli_connect("localhost", "root", "","webna");
		mysqli_set_charset($conn,'utf8');
		if (!$conn) {
		    die("Connection failed: " . mysqli_connect_error());
		}
		return $conn;
	}
	$conn = connect();
	class model {
		public function get_all_table($table){
			$conn = connect();
			$res = mysqli_query($conn,"SELECT * FROM ".$table);
			// if (mysqli_num_rows($res) > 0) {
			//     // Sử dụng vòng lặp while để lặp kết quả
			//     while($row = mysqli_fetch_assoc($res)) {
			//         echo "ID: " . $row["Idproduct"]. " - Tên: " . $row["Nameproduct"]. "<br>";
		 //    	}
			// }
			// else {
			//     echo "Không có record nào";
			// }

			// ngắt kết nối
			mysqli_close($conn);
			return $res;
		}



		public function get_num_row($table,$numb){
			$conn = connect();
			$_res = mysqli_query($conn,"SELECT * FROM ".$table);
			$count = mysqli_num_rows($_res);
			if($count%2==0){
				$num1 = $count/2;
				$num2 = $count/2;
			} else{
				$num1 = ($count+1)/2;
				$num2 = ($count-1)/2;
			}
			if($numb == 1){
				$res = mysqli_query($conn,"SELECT * FROM product LIMIT {$num1} OFFSET 0 ");
			} else{
				$res = mysqli_query($conn,"SELECT * FROM product LIMIT {$num2} OFFSET {$num1} ");
			}
			mysqli_close($conn);
			return $res;
		}
		public function get_end_table($table){
			$conn = connect();
			$_res = mysqli_query($conn,"SELECT * FROM ".$table);
			$count = mysqli_num_rows($_res);
			$count = $count - 5;
				$res = mysqli_query($conn,"SELECT * FROM {$table} LIMIT 5 OFFSET {$count}");

			mysqli_close($conn);
			return $res;
		}
		public function insert_custom($phone, $address, $email, $name){
			$conn = connect();
			$res =  mysqli_query($conn, "INSERT INTO `user` (`Phone`, `Address`, `Email`, `Name`, `Type`) VALUES ('$phone', '$address', '$email', '$name', '0')");
			return $res;
		}

		public function insert_bill($idproduct,$num,$id,$datebill){
			$conn = connect();
			$res =  mysqli_query($conn,"INSERT INTO `bill` (`Idproduct`, `Number`, `Id`,`Datebill`) VALUES ('$idproduct', '$num', '$id',now());");
			return $res;
		}

		//lấy ra 1 hàng
		public function get_one_row($table,$row,$value){
			$conn = connect();
			$res = mysqli_query($conn,"SELECT * FROM {$table}  WHERE  {$row} = '{$value}' ");

				return $res;
		}

		//lấy sản phẩm theo loại get_hangson
		public function get_bycategory($category){
			$conn = connect();
			$res = mysqli_query($conn,"SELECT * FROM product p JOIN categories c ON p.Idcategory=c.Idcategory AND c.Namecategory= '{$category}' ");
			return $res;
		}


		public function insert_user($username,$password,$phone,$address,$email,$name,$dateofbirth){
			$conn = connect();
			$res = mysqli_query($conn,"INSERT INTO `user` ( `Username`, `Password`, `Phone`, `Address`, `Email`, `Name`, `Type`, `Dateofbirth`) VALUES ( '$username',('$password'), '$phone', '$address', '$email', '$name', '0', '$dateofbirth')")	;
			return $res;
		}

		// tìm kiếm pro
		public function search_pro($str){
			$conn = connect();
			$res = mysqli_query($conn,"SELECT * FROM product p JOIN categories c ON p.Idcategory=c.Idcategory AND(p.Nameproduct LIKE '%{$str}%' OR c.Namecategory like '%{$str}%')");
			return $res;
		}
		//thêm review
		public function insert_review($name,$star,$review,$idproduct,$date){
			$conn = connect();
			$res = mysqli_query($conn,"INSERT INTO `review` (`Namereviewer`, `Star`, `Review`, `Idproduct`, `Datereview`) VALUES ('$name', '$star', '$review', '$idproduct', '$date');");
		}

		//sửa thông tin user
		public function update_user($phone,$address,$email,$name,$dob,$iduser){
			$conn = connect();
			$res =  mysqli_query($conn,"UPDATE `user` SET `Phone` = '$phone', `Address` = '$address', `Email` = '$email', `Name` = '$name', `Dateofbirth` = '$dob' WHERE `user`.`Id` = '$iduser'; ");
		}
		//kết bản bill với product và lấy ra tất cả các đơn hàng mà user đã mua
		public function lichsu($iduser){
			$conn = connect();
			$res =  mysqli_query($conn,"SELECT * FROM bill,product WHERE bill.Idproduct = product.Idproduct and bill.Id = '$iduser'; ");
			return $res;
		}

	}
?>
