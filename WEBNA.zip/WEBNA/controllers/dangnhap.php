<?php
require_once 'models/model.php';
require_once 'views/index.php';
class dangnhap{
	function index(){
		 if (isset($_POST['submit'])){
                        if(empty($_POST['txtUsername']) or empty($_POST['txtPassword'])){
                            echo '<p style="color:red">Vui lòng nhập đầy đủ thông tin đăng nhập!</p>';
                        }
                        else{
                            require_once 'models/model.php';
                            $username = $_POST['txtUsername'];
                            $password = $_POST['txtPassword'];
                           // $password = md5($password);
                            $tmp = new model();
                            $res = $tmp->get_one_row('user','Username',$username);
                            if(mysqli_num_rows($res) > 0){
                                $row = mysqli_fetch_assoc($res);
                                if($row['Password'] == $password){
                                    $_SESSION['Username'] = $row['Name'];
                                    $_SESSION['Email'] = $row['Email'];
                                    $_SESSION['Id'] = $row['Id'];
									$_SESSION['Type'] = $row['Type'];
									$_SESSION['admin_name'] = $row['Name'];
									$_SESSION['admin_id'] = $row['Id'];
                                     echo "<script>alert(' Đăng nhập thành công '); location.href='index.php' </script>";

                                 } else{
                                     echo "<script>alert('Mật khẩu không đúng!'); </script>";
                                 }
                            } else{
                                echo "<script>alert('Tên đăng nhập không tồn tại!'); </script>";
                            }
                        }
                    }
		require_once 'views/dangnhap.php';
	}
}
