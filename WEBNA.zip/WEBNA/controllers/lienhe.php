<?php
require_once 'models/model.php';
require_once 'views/index.php';
class lienhe{
	function index(){
		session_destroy();
		require_once 'views/lienhe.php';
	}
}
