<?php
require_once 'models/model.php';
require_once 'views/index.php';


class trangchu{

	function index(){
		//session_destroy();
		require_once 'views/trangchu.php';
	}
	function index1(){
		if(isset($_SESSION['Username'])){
			unset($_SESSION['Username']);
			unset($_SESSION['User']);
		//	unset($_SESSION['Type']);
		}
		require_once 'views/trangchu.php';
	}
}
