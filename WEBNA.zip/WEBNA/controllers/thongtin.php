<?php
require_once 'models/model.php';
require_once 'views/index.php';
class thongtin{
	function index(){
		$tmp = new model();
		if(isset($_SESSION['Username'])){
			$user = mysqli_fetch_assoc($tmp->get_one_row('user','Name',$_SESSION['Username']));
		}
		if(isset($_POST['txtEmail'])){
			$email = $_POST['txtEmail'];
			$phone = $_POST['txtPhone'];
			$address = $_POST['txtAddress'];
			$name = $_POST['txtFullname'];
			$dob = $_POST['txtBirthday'];
			$iduser = $user['Id'];
			$res = $tmp->update_user($phone,$address,$email,$name,$dob,$iduser);
			$_SESSION['Username'] = $name;
			 echo "<script>alert(' Sửa thông tin thành công. '); location.href='index.php' </script>";
		}
		require_once 'views/thongtin.php';
	}
}