<?php
require_once 'models/model.php';
require_once 'views/index.php';

class sanpham{
	function detail(){
		$tmp = new model();
		$ganday = $tmp->get_end_table('product');
		//chọn sản phẩm để xem
		if(isset($_GET['id'])){
			$pro = $tmp->get_one_row("product","Idproduct",$_GET['id']);
			if(mysqli_num_rows($pro) > 0) {
				$row = mysqli_fetch_assoc($pro);
				if($row['Idcategory'] == 1) $hang = 'CONVERSE';
				if($row['Idcategory'] == 2) $hang = 'VANS';
				if($row['Idcategory'] == 3) $hang = 'K-SWISS';
				if($row['Idcategory'] == 4) $hang = 'PALLADIUM';
			}
			else {
				$pro = $tmp->get_all_table('product');
				$hang = 'CONVERSE';
				$row = mysqli_fetch_assoc($pro);
			}
		} else{
			$pro = $tmp->get_all_table('product');
			$hang = 'CONVERSE';
			$row = mysqli_fetch_assoc($pro);
		}
		$rev = $tmp->get_one_row('review','Idproduct',$row['Idproduct']);
		$lienquan = $tmp->get_bycategory($hang);


		//tìm chuỗi đánh giá
		if(isset($_POST['star'])){
			$name = $_POST['namereview'];
			$star = $_POST['star'];
			$review = $_POST['review'];
			$idproduct = $row['Idproduct'];
			$date = date("d/m/Y");
			$res = $tmp->insert_review($name,$star,$review,$idproduct,$date);

		}

			require_once "views/sanpham.php";

	}
}
