<?php
session_start();

//Thêm vào giỏ hàng từ addtocart
if(isset($_REQUEST['addid'])){
	$id = $_REQUEST['addid'];
	$t = $_REQUEST['addgia'];
	$a = $_SESSION['cart'];

	// nếu không chọn số lượng thêm thì thêm 1
	if(!isset($_REQUEST['addsl'])){
		if(array_key_exists($id, $a)){
			$a[$id] +=1;
		} else $a[$id] = 1;
		$_SESSION['sl'] += 1;
		$_SESSION['tong'] += $t;
	} else{
		if(array_key_exists($id, $a)){
			$a[$id] += $_REQUEST['addsl'];
		} else $a[$id] = $_REQUEST['addsl'];
		$_SESSION['sl'] += $_REQUEST['addsl'];
		$_SESSION['tong'] += $_REQUEST['addsl'] * $t;
	}
	$_SESSION['cart'] = $a;
	$tong = number_format($_SESSION['tong'],0,'.','.');
	$sl = number_format($_SESSION['sl'],0,'.','.');
	echo "Giỏ hàng: <span class='cart-amunt'>{$tong} VNĐ</span> <i class='fa fa-shopping-cart'></i><span class='product-count'>{$sl}</span>";
}
// trừ số lượng đi 1
if(isset($_REQUEST['truid']) && isset($_REQUEST['trugia'])){
	$id =$_REQUEST['truid'];
	$gia =$_REQUEST['trugia'];
	$a = $_SESSION['cart'];
	if(array_key_exists($id, $a) && $a[$id] > 1 && $_SESSION['tong'] > 0){
		$a[$id]  -= 1;
		$_SESSION['sl'] -= 1;
		$_SESSION['tong'] -= $gia;
		$_SESSION['cart'] = $a;
	}
	echo $_SESSION['tong'];
}

//cộng cho số lượng 1
if(isset($_REQUEST['congid']) && isset($_REQUEST['conggia'])){
	$id =$_REQUEST['congid'];
	$gia =$_REQUEST['conggia'];
	$a = $_SESSION['cart'];
	if(array_key_exists($id, $a)){
		$a[$id]  += 1;
		$_SESSION['sl'] += 1;
		$_SESSION['tong'] += $gia;
		$_SESSION['cart'] = $a;
	}
	echo $_SESSION['tong'];
}

// thay đổi số lượng sản phẩm
if(isset($_REQUEST['doiid']) && isset($_REQUEST['doigia']) && isset($_REQUEST['doisl'])){
	$id = $_REQUEST['doiid'];
	$gia = $_REQUEST['doigia'];
	$sl = $_REQUEST['doisl'];
	$a = $_SESSION['cart'];
	if(array_key_exists($id, $a)){
		$_SESSION['tong'] -= $a[$id]*$gia;
		$a[$id] = $sl;
		$_SESSION['tong'] += $a[$id]*$gia;
		$_SESSION['sl'] = 0;
		foreach ($a as $key => $value){
			$_SESSION['sl'] += $value;
		}
		$_SESSION['cart'] = $a;
	}
	echo $_SESSION['tong'];
}

//tính phí ship
if(isset($_REQUEST['ship'])){
	if($_REQUEST['ship'] == 'TPHCM') $_SESSION['ship'] = 30000;
	else $_SESSION['ship'] = 50000;
	echo $_SESSION['ship'];
}
//tìm kiếm sản phẩm
if(isset($_REQUEST['search_str'])){
	require_once ('../models/model.php');
	$tmp = new model();
	$pro = $tmp->search_pro($_REQUEST['search_str']);
	$res = "";
	 if(mysqli_num_rows($pro) > 0){
            $dem  = 0;
                while($rowa = mysqli_fetch_assoc($pro)){
                    if($dem < 4){
                        $tmph = 'public/images/product/'.$rowa['Image'];
                        $tm = number_format($rowa['Oldprice'],0,'.','.').' VNĐ';
                        $t = number_format($rowa['Newprice'],0,'.','.').' VNĐ';
                        $res.=   "<div class='thubmnail-recent'>";
                        $res.=        "<a href='?controller=sanpham&action=detail&id={$rowa['Idproduct']}'><img src='{$tmph}' class='recent-thumb'></a>";
                        $res.=        "<h2><a href='?controller=sanpham&action=detail&id={$rowa['Idproduct']}'>{$rowa['Nameproduct']}</a></h2>";
                        $res.=        "<div class='product-sidebar-price'>";
                        $res.=            "<ins>{$t}</ins> <del>{$tm}</del>";
                        $res.=       "</div>";
                        $res.=    "</div>";
                        $dem +=1;
                    }
                }
	        } else $res = "Không có sản phẩm nào!";
	    echo $res;
}
