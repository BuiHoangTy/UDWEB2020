<?php
require_once 'models/model.php';
require_once 'views/index.php';
class baohanh{
	function index(){
		session_destroy();
		require_once 'views/baohanh.php';
	}
}
