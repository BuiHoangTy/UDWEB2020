<?php
require_once 'models/model.php';
require_once 'views/index.php';
class pay{
	function index(){
		session_destroy();
		require_once 'views/pay.php';
	}
}
