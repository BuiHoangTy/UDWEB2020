<?php
require_once 'models/model.php';
require_once 'views/index.php';
class doitra{
	function index(){
		session_destroy();
		require_once 'views/doitra.php';
	}
}
