<?php  
require_once 'models/model.php';
require_once 'views/index.php';
class lichsu{
	public function index(){
		$tmp = new model();
		$res = $tmp->lichsu($_SESSION['Id']);
		require_once 'views/lichsu.php';
	}
}
?>