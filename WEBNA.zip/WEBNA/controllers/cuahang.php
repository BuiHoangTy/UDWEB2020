<?php
require_once 'models/model.php';
require_once 'views/index.php';
class cuahang{
	function page1(){
		$tmp = new model();
		$pro = $tmp->get_num_row('product',1);

		//var_dump($_SESSION['cart']);
		require_once 'views/cuahang.php';
	}
	function page2(){
		$tmp = new model();
		$pro = $tmp->get_num_row('product',2);

		require_once 'views/cuahang.php';
	}
	function converse(){
		$tmp = new model();
		$pro = $tmp->get_bycategory('CONVERSE');
		$count = mysqli_num_rows($pro);

		require_once 'views/cuahang.php';
	}
	function vans(){
		$tmp = new model();
		$pro = $tmp->get_bycategory('VANS');
		$count = mysqli_num_rows($pro);

		require_once 'views/cuahang.php';
	}
	function kswiss(){
		$tmp = new model();
		$pro = $tmp->get_bycategory('K-SWISS');
		$count = mysqli_num_rows($pro);

		require_once 'views/cuahang.php';
	}
	function palladium(){
		$tmp = new model();
		$pro = $tmp->get_bycategory('PALLADIUM');
		$count = mysqli_num_rows($pro);

		require_once 'views/cuahang.php';
	}
}
