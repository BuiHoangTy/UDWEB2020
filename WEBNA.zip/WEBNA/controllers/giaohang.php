<?php
require_once 'models/model.php';
require_once 'views/index.php';
class giaohang{
	function index(){
		session_destroy();
		require_once 'views/giaohang.php';
	}
}
