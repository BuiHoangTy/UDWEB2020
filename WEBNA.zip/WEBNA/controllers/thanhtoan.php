<?php
require_once 'models/model.php';
require_once 'views/index.php';


class thanhtoan{
	function index(){
		$tmp = new model();
		if(isset($_SESSION['Username'])){
			$res = $tmp->get_one_row('user','Name',$_SESSION['Username']);
			if(mysqli_num_rows($res) > 0) $row = mysqli_fetch_assoc($res);
		}
	  if(isset($_POST['hovaten'] )){
	        if( $_POST['hovaten'] == '' || $_POST['diachi'] == ''  || $_POST['calc_shipping_country'] == '' || $_POST['email'] == '' || $_POST['phone'] == ''){
	                 $t = true;
	        }
	        else{

	            if(isset($_SESSION['ship']) && $_SESSION['ship'] != 0){

	            	 if(!isset($_SESSION['Username']) && !empty($_SESSION['cart'])){
	             	$res_user = $tmp->insert_custom($_POST['phone'], $_POST['diachi'],$_POST['email'], $_POST['hovaten']);
	             		//$row_user = mysqli_fetch_assoc($res_user);
	             	var_dump($res_user);
	             	foreach ($_SESSION['cart'] as $key => $value) {
	             				$res_bill = $tmp->insert_bill($key,$value,null,$datebill);
	             			}
	             	unset($_SESSION['cart']);
	             	unset($_SESSION['tong']);
	             	unset($_SESSION['sl']);
	             	unset($_SESSION['ship']);


	             	} else if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])){
	             			foreach ($_SESSION['cart'] as $key => $value) {
	             				$res_bill = $tmp->insert_bill($key,$value,$row['Id'],$datebill);
	             			}
			             	unset($_SESSION['cart']);
			             	unset($_SESSION['tong']);
			             	unset($_SESSION['sl']);
			             	unset($_SESSION['ship']);

			        }

	            }




	        }
	    }

		        	if(isset($_POST['timkiem']) && $_POST['timkiem']!=''){
			         	$ab = $_POST['timkiem'];
			         	$ressearch = $tmp->search_pro($ab);
			         }

			         $lienquan = $tmp->get_end_table('product');
			         $lienquana = $tmp->get_end_table('product');

	        require_once ('views/thanhtoan.php');
	   }











}
