<?php  
require_once 'models/model.php';
require_once 'views/index.php';
class giohang{

	function index(){
		$tmpa = new model();
		if(isset($_POST['timkiem']) && $_POST['timkiem']!=''){
         	$ab = $_POST['timkiem'];
         	$ressearch = $tmpa->search_pro($ab);
         }
         $lienquan = $tmpa->get_end_table('product');
         $lienquana = $tmpa->get_end_table('product');
		require_once 'views/giohang.php';
	}
	function xoa(){
		$tmpa = new model();
		if(isset($_SESSION['cart']) &&  !empty($_SESSION['cart']) && isset($_GET['id']) && array_key_exists($_GET['id'],$_SESSION['cart'])){
			$tmp = $_SESSION['cart'];

			$_SESSION['tong'] -= $_GET['gia']*$tmp[$_GET['id']];
			$_SESSION['sl'] -=$tmp[$_GET['id']];

			unset($tmp[$_GET['id']]);
			$_SESSION['cart'] = $tmp;
		}	

		if(isset($_POST['timkiem']) && $_POST['timkiem']!=''){
         	$ab = $_POST['timkiem'];
         	$ressearch = $tmpa->search_pro($ab);
         }

         $lienquan = $tmpa->get_end_table('product');
         $lienquana = $tmpa->get_end_table('product');
		require_once 'views/giohang.php';	
	}
}