<?php  
require_once 'models/model.php';
require_once 'views/index.php';
class dangki{
	function index(){
			$tmp = new model();
			$pass = false;
			$checkuser = false;
			$test = false;
			if(isset($_POST['username'])){
				 if($_POST['password'] != $_POST['repassword']) $pass = true;

				 $res = $tmp->get_all_table('user');
				 if(mysqli_num_rows($res) > 0){
				 	while($row = mysqli_fetch_assoc($res)){
				 		if($row['Username'] == $_POST['username']) $checkuser = true;
				 	}
				 }

				 if(!$pass && !$checkuser){
				 	$res = $tmp->insert_user($_POST['username'],$_POST['password'],$_POST['phone'],$_POST['address'],$_POST['email'],$_POST['name'],$_POST['birthday']);
				 	if($res){ $_SESSION['Username'] = $_POST['username']; $test = true;}
				 }

			}	
			require_once 'views/dangki.php';
	}

}