<?php
   session_start();
   require_once __DIR__. "/../../libraries/Database.php";
   require_once __DIR__. "/../../libraries/Function.php";
   $db = new database;

   if(! isset($_SESSION['admin_id']))
   {
   	header("location: /au_admin/login/");
   }

   define("ROOT",$_SERVER['DOCUMENT_ROOT'] ."/tutphp/public/uploads/");
?>
