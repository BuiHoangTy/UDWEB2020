<?php

   $open="categories";
   require_once __DIR__. "/../../autoload/autoload.php";
   $category=$db->fetchAll("categories");
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Danh sách danh mục
                        <a href="add.php" class="btn btn-success">Thêm mới</a>
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['success'])) :?>
                        <div class="alert alert-success">
                              <?php echo $_SESSION['success']; unset($_SESSION['success'])  ?>
                        </div>
                     <?php endif ;?>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                           <thead>
                              <tr>
                                 <th>STT</th>
                                 <th>Tên danh mục</th>

                                 <th>Thao tác</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php $stt=1; foreach ($category as $item): ?>
                              <tr>
                                 <td><?php echo $stt ?></td>
                                 <td><?php echo $item['Namecategory'] ?></td>

                                 <td>
                                    <a class="btn btn-xs btn-danger" href="delete.php? id=<?php echo $item['Idcategory']?>">Xóa</a>
                                    <a class="btn btn-xs btn-info" href="edit.php? id=<?php echo $item['Idcategory']?>">Sửa</a>

                                 </td>
                              </tr>
                              <?php $stt++ ;endforeach ?>
                           </tbody>
                        </table>

                     </div>
                  </div>

               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
