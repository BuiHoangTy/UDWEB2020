<?php

   $open="categories";
   require_once __DIR__. "/../../autoload/autoload.php";
   if($_SERVER["REQUEST_METHOD"]=="POST")
   {
      $data=
      [
         "Namecategory"=>postInput('Namecategory')
      ];
      $error=[];
      if(postInput('Namecategory')=='')
      {
         $error['Namecategory']="Nhập tên danh mục";
      }
      if(empty($error))
      {
         $isset=$db->fetchOne("categories"," Namecategory ='".$data['Namecategory']."' ");


         if($isset != NULL)
         {
            $_SESSION['error']="Tên danh mục đã tồn tại";
         }
         else
         {
            $id_insert = $db->insert("categories",$data);
            if($id_insert>0)
            {
               $_SESSION['success']="Thêm thành công";
               redirectAdmin("/category/index.php");
            }
            else
            {
               $_SESSION['error']="Thêm thất bại";

            }
         }
      }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Thêm danh mục
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST">
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên danh mục</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập Tên danh mục" name="Namecategory">
                              <?php if (isset($error['Namecategory'])): ?>
                                 <p class="text-danger"><?php echo $error['Namecategory'] ?></p>
                              <?php endif ?>

                           </div>
                        </div>
                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default">Lưu</button>
                           </div>
                        </div>
                        </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA/au_admin/admin/modules/category/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
