<?php

   $open="categories";
   require_once __DIR__. "/../../autoload/autoload.php";
   $id=intval(getInput('id'));
   // echo $id;
   $EditCategory=$db->fetchID_category("categories",$id);

   if(empty($EditCategory)){
      $_SESSION['error']="Dữ liệu không tồn tại";
      redirectAdmin("/category/index.php");
   }
   $is_product = $db->fetchOne("product"," Idcategory = $id");
   if($is_product == NULL)
   {
      $num=$db->delete_category("categories",$id);
      if($num>0)
      {
         $_SESSION['success']="Xóa thành công";
         redirectAdmin("/category/index.php");
      }
      else{
         $_SESSION['error']="Xóa thất bại";
         redirectAdmin("/category/index.php");
      }
   }
   else
   {
      $_SESSION['error']="Không xóa được vì danh mục có sản phẩm";
      redirectAdmin("category");
   }
?>
