<?php

   $open="categories";
   require_once __DIR__. "/../../autoload/autoload.php";

   $id=intval(getInput('id'));

   $EditCategory=$db->fetchID_category("categories",$id);
   $hau = $EditCategory['Namecategory'];
   if(empty($EditCategory))
   {
      $_SESSION['error']="Dữ liệu không tồn tại";
      redirectAdmin("/category/index.php");
   }
   if($_SERVER["REQUEST_METHOD"]=="POST")
   {
      // $data=
      // [
         $Namecategory=$_REQUEST['Namecategory'];
      // ];
      $error=[];
      if(postInput('Namecategory')=='')
      {
         $error['Namecategory']="Nhập tên danh mục";
      }
      if(empty($error))
      {
         // $suong ="SELECT * FROM prducer WHERE Namecategory LIKE '$Namecategory'";
         // // $isset=$db->fetchOne("prducer","Namecategory = '".$data['Namecategory']."' ");
         // $id_update = mysqli_query($db->link,$suong);

         // if($id_update  !=NUL)
         // {
         //    $_SESSION['error']="$Namecategory";
         // }
         if ($_SESSION['office']==1)
         {
             $hau = "update category set Namecategory = '$Namecategory' where Idcategory like '$id'";

            $id_update = mysqli_query($db->link,$hau);
            // $id_update = $db->update("prducer",$data,array("Idcategory"=>$id));
            if($id_update >0)
            {
               $_SESSION['success']="Sửa thành công";
               redirectAdmin("/category/index.php");
            }
            else
            {
               $_SESSION['error']="Dữ liệu không đổi";
               redirectAdmin("/category/index.php");
            }
         }
      }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Thêm danh mục
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST">
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên danh mục</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Tên danh mục" name="Namecategory" value="<?php echo $hau ?>">
                              <?php if (isset($error['Namecategory'])): ?>
                                 <p class="text-danger"><?php echo $error['Namecategory'] ?></p>
                              <?php endif ?>

                           </div>
                        </div>
                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default">Lưu</button>
                           </div>
                        </div>
                        </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA//au_admin/admin/modules/category/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
