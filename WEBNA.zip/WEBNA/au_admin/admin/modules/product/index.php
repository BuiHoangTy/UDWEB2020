<?php

   $open="product";
   require_once __DIR__. "/../../autoload/autoload.php";
   $product=$db->fetchAll("product");
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Danh sách danh mục
                        <a href="add.php" class="btn btn-success">Thêm mới</a>
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['success'])) :?>
                        <div class="alert alert-success">
                              <?php echo $_SESSION['success']; unset($_SESSION['success'])  ?>
                        </div>
                     <?php endif ;?>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                           <thead>
                              <tr>
                                 <th>STT</th>
                                 <th>Tên sản phẩm</th>
                                 <th>Hình ảnh</th>
                                 <th>Thông tin</th>

                                 <th>Thao tác</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php $stt=1; foreach ($product as $item): ?>
                              <?php
                              $ten = $item['Nameproduct'];

                              $hinh = "anh/" .$item['Image'];
                              $hinh = "<img src = '$hinh' alt = '$ten' width='80px' height='80px' ";
                              ?>
                              <tr>
                                 <td><?php echo $stt ?></td>
                                 <td><?php echo $item['Nameproduct'] ?></td>
                                 <!-- <img src="anh/dulux1.png"> -->
                                 <td>
                                    <?php  echo $hinh ?>
                                 </td>
                                 <td>
                                    <ul>

                                       <li><b>Giá: </b> <?php echo number_format($item['Newprice'],0,'.','.').' VNĐ' ?></li>
                                       <li><b>Mô Tả: </b> <?php echo $item['Description'] ?></li>
                                    </ul>
                                 </td>
                                 <td>
                                    <a class="btn btn-xs btn-danger" href="delete.php?id=<?php echo $item['Idproduct']?>">Xóa</a>
                                    <a class="btn btn-xs btn-info" href="edit.php?id=<?php echo $item['Idproduct']?>">Sửa</a>

                                 </td>
                              </tr>
                              <?php $stt++ ;endforeach ?>
                           </tbody>
                        </table>

                     </div>
                  </div>

               </div>


               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
