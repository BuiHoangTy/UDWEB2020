<?php

   $open="product";
   require_once __DIR__. "/../../autoload/autoload.php";
   $id=intval(getInput('id'));

   $Editproduct=$db->fetchID_product("product",$id);

   if(empty($Editproduct))
   {
      $_SESSION['error']="Dữ liệu không tồn tại";
      redirectAdmin("product");
   }
   $category=$db->fetchAll("product");
   $danhmuc =$db->fetchAll("categories");
   if($_SERVER["REQUEST_METHOD"]=="POST")
   {

         $name = postInput('name');
         $category_id = postInput('category_id');
         $price = postInput('price');
         $mota = postInput('mota');


      $error=[];
      if(postInput('name')=='')
      {
         $error['name']="Nhập tên sản phẩm";
      }
      if(postInput('category_id')=='')
      {
         $error['category_id']="Nhập tên danh mục";
      }
      if(postInput('price')=='')
      {
         $error['price']="Nhập giá sản phẩm";
      }
      if(postInput('mota')=='')
      {
         $error['mota']="Nhập Mô tả ";
      }

      if($_FILES['thunbar'] == NULL)
      {
         $error['thunbar']="Chọn hình đại diện";
      }


      if(empty($error))
      {

         if(isset($_FILES['thunbar']))
         {
            $file_name=$_FILES['thunbar']['name'];
            $file_tmp=$_FILES['thunbar']['tmp_name'];
            $file_type=$_FILES['thunbar']['type'];
            $file_erro=$_FILES['thunbar']['error'];

            if($file_erro==0){
               $part= "anh/".$file_name;
               // $data['thunbar']=$file_name;
            }
         }

         $hau = "UPDATE product SET Nameproduct = '$name', Price = '$price', Image = '$file_name', Description= '$mota', Idcategory = '$category_id' WHERE Idproduct = '$id'    ";

            $id_update = mysqli_query($db->link,$hau);

         if($id_update != NULL)
         {

            move_uploaded_file($file_tmp, $part);
            $_SESSION['success']="Cập nhật thành công";
            redirectAdmin("product");
         }
         else
         {
            $_SESSION['error']="Cập nhật thất bại";
            redirectAdmin("product");
         }
      }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Sửa thông tin sản phẩm
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Danh mục sản phẩm</label>
                           <div class="col-sm-8">
                              <select class="form-control col-md-8" name="category_id" >


                                 <?php foreach ($danhmuc as $item): ?>
                                 <?php $idhau =  $item['Idcategory']; ?>

                                    <option value="<?php echo $idhau ?>" > <?php echo $item['Namecategory'] ?></option>
                                 <?php endforeach?>


                              </select>

                              <?php if (isset($error['category'])): ?>
                                 <p class="text-danger"><?php echo $error['category'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên sản phẩm</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Tên sản phẩm" name="name" value="<?php echo $Editproduct['Nameproduct'] ?>">
                              <?php if (isset($error['name'])): ?>
                                 <p class="text-danger"><?php echo $error['name'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Giá sản phẩm</label>
                           <div class="col-sm-8">
                              <input type="number" class="form-control" id="inputEmail3" placeholder="VNĐ" name="price" value="<?php echo $Editproduct['Newprice'] ?>">
                              <?php if (isset($error['price'])): ?>
                                 <p class="text-danger"><?php echo $error['price'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Hình Ảnh</label>
                           <div class="col-sm-3">
                              <input type="file" class="form-control" id="inputEmail3" name="thunbar" value="<?php echo $Editproduct['Image'] ?>" >
                              <?php if (isset($error['thunbar'])): ?>
                                 <p class="text-danger"><?php echo $error['Image'] ?></p>
                              <?php endif ?>
                              <img src="<?php echo 'anh/'.$Editproduct['Image'] ?>" width="50px" height="50px">
                           </div>

                        </div>


                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Mô Tả</label>
                           <div class="col-sm-8">
                              <textarea name="mota" class="form-control" rows="4 "><?php echo $Editproduct['Description']?></textarea>
                              <?php if (isset($error['mota'])): ?>
                                 <p class="text-danger"><?php echo $error['mota'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default">Lưu</button>
                           </div>
                        </div>
                        </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA/au_admin/admin/modules/admin/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
