<?php

   $open="user";
   require_once __DIR__. "/../../autoload/autoload.php";
   // $Check = $_SESSION['office'];
   $data=
      [
         "username" => postInput('username'),
         "name"=>postInput('name'),
         "email"=>postInput('email'),
         "phone"=>postInput('phone'),
         "password"=>postInput('password'),
         "address"=>postInput('address'),
         "type"=>postInput('type'),
         "Dateofbirth"=>postInput('Dateofbirth')
      ];

   if($_SERVER["REQUEST_METHOD"]=="POST")
   {

      $error=[];
      if(postInput('name')=='')
      {
         $error['name']="Nhập họ và tên";
      }

      // check email
      if(postInput('email')=='')
      {
         $error['email']="Nhập email";
      }
      else
      {
         $is_check = $db->fetchOne("user"," email ='".$data['email']."' ");
         if($is_check != NULL)
         {
            $error['email'] = "Email bị trùng";
         }
      }
      $rong=' ';
      // check user

      if(postInput('username')=='')
      {
         $error['username']="Nhập username";
      }
      else
      {
         $is_check = $db->fetchOne("user"," Username ='".$data['username']."' ");
         if($is_check != NULL)
         {
            $error['username'] = "username bị trùng";
         }
      }

      if(postInput('phone')=='')
      {
         $error['phone']="Nhập số điện thoại";
      }
      if(postInput('password')=='')
      {
         $error['password']="Nhập mật khẩu";
      }
      if(postInput('address')=='')
      {
         $error['address']="Nhập địa chỉ";
      }
      if(postInput('office')=='')
      {
         $error['office']="Nhập Chức Vụ";
      }
      if($data['password'] != postInput("re_password")){
         $error['password']="Mật khẩu không khớp";
      }
      if(postInput('Dateofbirth')=='')
      {
         $error['Dateofbirth']="Nhập Ngày Sinh";
      }


      if(empty($error))
      {
          $id_insert=$db->insert("user",$data);

         if($id_insert != NULL)
         {

            $_SESSION['success']="Thêm mới thành công";
            echo "<script>alert(' Thêm mới thành công !!!');  </script>";
            redirectAdmin("/admin/index.php");
            // /tutphp/admin/modules/admin/
         }
         else
         {
            $_SESSION['error']="Thêm mới thất bại";
            echo "<script>alert(' Thêm mới thất bại ');  </script>";
         }
      }
      // else{
      //    echo "<script>alert(' Bạn Không phải là AdMin '); location.href='../admin/index.php' </script>";
      // }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Thêm Tài Khoản
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Họ và tên</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập Họ và tên" name="name" value="<?php echo $data['name'] ?>">
                              <?php if (isset($error['name'])): ?>
                                 <p class="text-danger"><?php echo $error['name'] ?></p>
                              <?php endif ?>

                           </div>
                           </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên đăng nhập</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập user name" name="username" value="<?php echo "" ?>">
                              <?php if (isset($error['username'])): ?>
                                 <p class="text-danger"><?php echo $error['username'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Mật khẩu </label>
                           <div class="col-sm-8">
                              <input type="password" class="form-control" id="inputEmail3" placeholder="Nhập PassWord" name="password"  value="">
                              <?php if (isset($error['password'])): ?>
                                 <p class="text-danger"><?php echo $error['password'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Nhập lại mật khẩu</label>
                           <div class="col-sm-8">
                              <input type="password" class="form-control" id="inputEmail3" placeholder="Nhập lại Password" name="re_password" required="">
                              <?php if (isset($error['re_password'])): ?>
                                 <p class="text-danger"><?php echo $error['re_password'] ?></p>
                              <?php endif ?>

                           </div>
                           </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Email</label>
                           <div class="col-sm-8">
                              <input type="email" class="form-control" id="inputEmail3" placeholder="Nhập Email" name="email" value="<?php echo $data['email'] ?>">
                              <?php if (isset($error['email'])): ?>
                                 <p class="text-danger"><?php echo $error['email'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>



                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Số điện thoại</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập SDT" name="phone" value="<?php echo $data['phone'] ?>">
                              <?php if (isset($error['phone'])): ?>
                                 <p class="text-danger"><?php echo $error['phone'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Ngày Sinh: </label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập ngày sinh dd/mm/yyyy" name="Dateofbirth" >
                              <?php if (isset($error['dayofbirth'])): ?>
                                 <p class="text-danger"><?php echo $error['dayofbirth'] ?></p>
                              <?php endif ?>
                           </div>
                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Địa chỉ</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập Địa chỉ" name="address" value="<?php echo $data['address'] ?>">
                              <?php if (isset($error['address'])): ?>
                                 <p class="text-danger"><?php echo $error['address'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Chức Vụ</label>
                           <div class="col-sm-8">
                               <select class="form-control col-md-8" name="office" >

                                    <option value="1" > Admin</option>
                                    <option value="0" > Thành Viên</option>
                                    </select>
                              <?php if(isset($error['type'])): ?>
                                 <p class="text-danger"> <?php echo $error['office'] ?> </p>
                              <?php endif?>
                           </div>

                        </div>



                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default" style="color: blue">Lưu</button>

                           </div>
                        </div>
                     </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA//au_admin/admin/modules/admin/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
