<?php
   
   $open="user"; 
   require_once __DIR__. "/../../autoload/autoload.php";
   $id= intval(getInput('id'));
   $Deleteadmin=$db->fetchID("user",$id);

    $hau = "UPDATE user SET Password ='cfcd208495d565ef66e7dff9f98764da' WHERE Id = '$id' ";



        $id_update = mysqli_query($db->link,$hau);

   if(empty($Deleteadmin)){
      $_SESSION['error']="Dữ liệu không tồn tại";
      redirectAdmin("/admin/index.php");
   }
  
   if($id_update != NULL)
   {
      $_SESSION['success']="Resrt thành công";
     redirectAdmin("/admin/index.php");;
   }
   else{
      $_SESSION['error']="Resrt thất bại";
     redirectAdmin("/admin/index.php");
   }
?>
