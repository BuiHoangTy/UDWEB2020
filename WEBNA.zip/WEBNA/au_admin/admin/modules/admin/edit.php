<?php

   $open="user";
   require_once __DIR__. "/../../autoload/autoload.php";

   $id= intval(getInput('id'));

   $Editadmin=$db->fetchID("user",$id);
   $username= $Editadmin['Username'];
   // $Check = $_SESSION['office'];
   if(empty($Editadmin))
   {
      $_SESSION['error']="Dữ liệu không tồn tại";
      redirectAdmin("user");
   }



   if($_SERVER["REQUEST_METHOD"]=="POST")
   {
      // $data=
      // [

         $name= $_REQUEST['name'];
         $email= $_REQUEST['email'];
         $phone= $_REQUEST['phone']  ;
         $password= $_REQUEST['password'];
         $address= $_REQUEST['address'];
         $office= $_REQUEST['type'];
         $Dateofbirth= $_REQUEST['Dateofbirth'];
      // ];

      $error=[];
      if(postInput('name')=='')
      {
         $error['name']="Nhập họ và tên";
      }
      if(postInput('email')=='')
      {
         $error['email']="Nhập email";
      }

      if(postInput('phone')=='')
      {
         $error['phone']="Nhập số điện thoại";
      }

       if(postInput('Dateofbirth')=='')
      {
         $error['Dateofbirth']="Nhập Ngày Sinh";
      }

      if(postInput('address')=='')
      {
         $error['address']="Nhập địa chỉ";
      }
      if(postInput('office')=='')
      {
         $error['office']="Nhập cấp bậc";
      }
      if(postInput('password') != NULL && postInput("re_password") !=NULL)
      {
         if(postInput('password') != postInput('re_password'))
         {
            $error['password'] = "Mật khẩu thay đổi không khớp";
         }
         else
         {
            $data['password'] = postInput("password");
         }
      }
      if($username !="" && $_SESSION['office']==1 )
      {

         $hau = "update user set Name = '$name', Username ='$username' , Password ='$password', Email ='$email' ,
        Phone = '$phone'  , Address='$address' , Office = '$office' , Dateofbirth='$Dateofbirth' where Id like '$id'";


        $id_update = mysqli_query($db->link,$hau);

         // $id_update=$db->update("user",$data,array("id"=>$id));
         if($id_update > 0)
         {

            $_SESSION['success']="Cập nhật thành công";
            redirectAdmin("/admin/index.php");
         }
         else
         {
            $_SESSION['error']="Cập nhật thất bại";
            redirectAdmin("/admin/index.php");
         }
      }
      else{
         echo "<script>alert(' Bạn Không phải là AdMin '); location.href='../admin/index.php' </script>";
      }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Sửa Tài Khoản
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Họ và tên</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập Họ và tên" name="name" value="<?php echo $Editadmin['Name'] ?>">
                              <?php if (isset($error['name'])): ?>
                                 <p class="text-danger"><?php echo $error['name'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên đăng nhập</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" readonly="true" placeholder="Nhập tên đăng nhập" name="username" value="<?php echo $Editadmin['Username'] ?>">
                              <?php if (isset($error['username'])): ?>
                                 <p class="text-danger"><?php echo $error['username'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>


                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Mật khẩu</label>
                           <div class="col-sm-8">
                              <input type="password" class="form-control" id="inputEmail3" placeholder="Nhập mật khẩu" name="password"  value="">
                              <?php if (isset($error['password'])): ?>
                                 <p class="text-danger"><?php echo $error['password'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Nhập lại mật khẩu</label>
                           <div class="col-sm-8">
                              <input type="password" class="form-control" id="inputEmail3" placeholder="Nhập lại mật khẩu" name="re_password" value="">
                              <?php if (isset($error['re_password'])): ?>
                                 <p class="text-danger"><?php echo $error['re_password'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Email</label>
                           <div class="col-sm-8">
                              <input type="email" class="form-control" id="inputEmail3" placeholder="Nhập Email" name="email" value="<?php echo $Editadmin['Email'] ?>">
                              <?php if (isset($error['email'])): ?>
                                 <p class="text-danger"><?php echo $error['email'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>



                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Số điện thoại</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập SDT" name="phone" value="<?php echo $Editadmin['Phone'] ?>">
                              <?php if (isset($error['phone'])): ?>
                                 <p class="text-danger"><?php echo $error['phone'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Ngày Sinh: </label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập ngày sinh dd/mm/yyyy" name="Dateofbirth" value="<?php echo $Editadmin['Dateofbirth'] ?>" >
                              <?php if (isset($error['Dateofbirth'])): ?>
                                 <p class="text-danger"><?php echo $error['Dateofbirth'] ?></p>
                              <?php endif ?>
                           </div>
                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Địa chỉ</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Nhập đỉa chỉ" name="address" value="<?php echo $Editadmin['Address'] ?>">
                              <?php if (isset($error['address'])): ?>
                                 <p class="text-danger"><?php echo $error['address'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>

                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Chức Vụ</label>
                           <div class="col-sm-8">
                              <select class="form-control col-md-8" name="office" >


                                    <option name="chucvu" value="1" <?php if($Editadmin['Type'] ==1)  echo 'selected' ?>    > Admin</option>
                                    <option name="chucvu" value="0" <?php if($Editadmin['Type'] ==0)  echo 'selected' ?>   > Thành Viên</option>
                              </select>
                              <?php if(isset($error['office'])): ?>
                                 <p class="text-danger"> <?php echo $error['office'] ?> </p>
                              <?php endif?>
                           </div>

                        </div>



                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default">Lưu</button>
                           </div>
                        </div>
                        </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA/au_admin/admin/modules/admin/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
