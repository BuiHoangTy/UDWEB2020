<?php

   $open="bill";
   require_once __DIR__. "/../../autoload/autoload.php";

   $bill=$db->fetchAll("bill");
   $sanpham=$db->fetchAll("categories");
   if($_SERVER["REQUEST_METHOD"]=="POST")
   {
      // $data=
      // [
         $namesp=postInput('name');
         $price=postInput('sum');
         $date=postInput('date');
         $user_id=postInput('user_id');

      // ];
      $error=[];
      if(postInput('name')=='')
      {
         $error['name']="Nhập tên sản phẩm";
      }
      if(postInput('category_id')=='')
      {
         $error['category_id']="Nhập tên khách hàng";
      }
      if(postInput('price')=='')
      {
         $error['price']="Nhập số tiền";
      }

      if(postInput('date')=='')
      {
         $error['date']="Nhập ngày ";
      }
      // if(! isset($_FILES['thunbar']))
      // {
      //    $error['thunbar']="Chọn hình đại diện";
      // }

      // if($category_id != NULL)
      // {
      //    if(isset($_FILES['thunbar']))
      //    {
      //       $file_name=$_FILES['thunbar']['name'];
      //       $file_tmp=$_FILES['thunbar']['tmp_name'];
      //       $file_type=$_FILES['thunbar']['type'];
      //       $file_erro=$_FILES['thunbar']['error'];
      //       if($file_erro==0){
      //
      //          // $data['thunbar']=$file_name;
      //       }
      //    }
         // $id_insert=$db->insert("product",$data);
         $tmp =$file_name;
         $hau = "INSERT INTO `bill` (`Idproduct`, `Number`, `Id`,`Datebill`) VALUES ('$idproduct', '$num', '$id',now());";

            $id_insert =mysqli_query($db->link,$hau);
         if($id_insert!=NULL)
         {
             // $imagePath = "images/" .$_FILES["file"]["name"];
             //   move_uploaded_file($_FILES["file"]["tmp_name"], $imagePath);
            $part= "anh/".$file_name;
            move_uploaded_file($file_tmp, $part);
            move_uploaded_file($file_tmp, 'public/images'.$file_name);
            $_SESSION['success']="Thêm mới thành công";
            redirectAdmin("product");
         }
         else
         {
            $_SESSION['error']="Thêm mới thất bại";
         }
      }
   }
?>
<?php require_once __DIR__. "/../../layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header">
                        Thêm sản phẩm
                     </h1>

                     <div class="clearfix"></div>
                     <?php if(isset($_SESSION['error'])) :?>
                        <div class="alert alert-danger">
                              <?php echo $_SESSION['error']; unset($_SESSION['error'])  ?>
                        </div>
                     <?php endif ;?>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Danh mục sản phẩm</label>
                           <div class="col-sm-8">
                              <select class="form-control col-md-8" name="category_id" value="Chọn danh mục">

                                 <?php foreach ($danhmuc as $item): ?>
                                 <?php $hau =$item['Idcategory']; ?>

                                    <option value=" <?php echo $hau ?>"><?php echo $item['Namecategory']?></option>

                                 <?php endforeach?>
                              </select>

                              <?php if (isset($error['category'])): ?>
                                 <p class="text-danger"><?php echo $error['category'] ?></p>
                              <?php endif ?>
                              <!-- <?php echo $hau?> -->
                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Tên sản phẩm</label>
                           <div class="col-sm-8">
                              <input type="text" class="form-control" id="inputEmail3" placeholder="Tên sản phẩm" name="name">
                              <?php if (isset($error['name'])): ?>
                                 <p class="text-danger"><?php echo $error['name'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Giá sản phẩm</label>
                           <div class="col-sm-8">
                              <input type="number" class="form-control" id="inputEmail3" placeholder="VNĐ" name="price">
                              <?php if (isset($error['price'])): ?>
                                 <p class="text-danger"><?php echo $error['price'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label">Hình ảnh</label>
                           <div class="col-sm-3">
                              <input type="file" class="form-control" id="inputEmail3" name="thunbar" >
                              <?php if (isset($error['thunbar'])): ?>
                                 <p class="text-danger"><?php echo $error['thunbar'] ?></p>
                              <?php endif ?>
                           </div>

                        </div>


                        <div class="form-group">
                           <label for="inputemail3" class="col-sm-2 control-label" placeholder="Nhập mô tả">Mô Tả</label>
                           <div class="col-sm-8">
                              <textarea name="mota" class="form-control" rows="4 "></textarea>
                              <?php if (isset($error['mota'])): ?>
                                 <p class="text-danger"><?php echo $error['mota'] ?></p>
                              <?php endif ?>

                           </div>

                        </div>
                        <div class="form-group">
                           <div class="col-sm-offset-2 col-sm-10">
                              <button type="submit" class="btn btn-default">Lưu</button>
                           </div>
                        </div>
                        </form>
                     <div style="text-align: center;">
                        <button type="submit" class="btn btn-default" style="text-align: center;">  <a href="/WEBNA/hau_admin/admin/modules/product/index.php">Trở Về</a></button>
                     </div>
                  </div>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/../../layouts/footer.php"; ?>
