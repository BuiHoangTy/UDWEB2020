<?php 
   require_once __DIR__. "/autoload/autoload.php";
   
   
   
?>
<?php require_once __DIR__. "/layouts/header.php"; ?>
               <!-- Page Heading -->
               <div class="row">
                  <div class="col-lg-12">
                     <h1 class="page-header glow" style="font-family: cursive;">
                        Xin chào <?php echo $_SESSION['admin_name'] ?> đến trang admin
                       
                     </h1>
               </div>
               <!-- /.row -->
<?php require_once __DIR__. "/layouts/footer.php"; ?>    