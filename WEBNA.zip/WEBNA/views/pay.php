<div class="mainmenu-area">
       <div class="container">
           <div class="row">
               <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                       <span class="sr-only">Toggle navigation</span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                   </button>
               </div>
               <div class="navbar-collapse collapse">
                   <ul class="nav navbar-nav">
                       <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                      <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                      <li><div class="shopping-item">
                       <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                   </div></li>

               </div>
           </div>
       </div>
   </div>



   <div class="content">

     <h3>*Các bước mua hàng:</h3>
     <p>
       - Bước 1: Khách hàng đặt hàng, cung cấp thông tin đầy đủ, xác thực (thông qua website, điện thoại, mail, sms..)
       <br>
       - Bước 2: HEAVEN SHOP xác thực đơn hàng
       <br>
       - Bước 3: Nhân viên xác nhận thông tin khách hàng (điện thoại, tin nhắn, mail..);
       <br>
       - Bước 4: Nhân viên chuyển hàng.
       <br>
       - Bước 5: Khách hàng nhận hàng và thanh toán (trong trường hợp thanh toán sau)
       <br>
       - Bước 6: HEAVEN SHOP luôn chờ những phản hồi của khách hàng (nếu có) sau khi hoàn tất giao dịch.
       <br>
     </p>


     <h4>1.    Phương thức trả sau: thanh toán khi nhận hàng.</h4>
     <ul>
       <li>Khách hàng có thể đặt hàng qua website HEAVEN SHOP hoặc qua tổng đài điện thoại của các cửa hàng trong hệ thống Converse Đăng Khoa. Nhân viên của chúng tôi sẽ gọi điện xác nhận với khách hàng về sản phẩm và phương thức vận chuyển.
   </li>
       <li>Quý khách có trách nhiệm thanh toán đầy đủ toàn bộ giá trị đơn hàng cho nhân viên giao nhận ngay sau khi hoàn tất kiểm tra sản phẩm (kiểm tra đúng sản phẩm đã đặt, đầy đủ phụ kiện đi kèm, phiếu bảo hành).
       </li>

     </ul>

     <h4>2.    Phương thức trả trước: thanh toán trước khi nhận hàng.</h4>
     <ul>
       <li> Thanh toán trực tuyến : thanh toán trực tiếp trên website Drạke.vn khi đặt đơn hàng bằng các loại thẻ Visa/Master/thẻ nội địa/ thẻ ghi nợ của tất cả các ngân hàng..
   </li>
       <li>Thanh toán chuyển khoản hoặc bằng máy ATM (qua ngân hàng): đã đặt xong đơn hàng hoặc đã xác nhận với cửa hàng về sản phẩm cần mua.
       </li>

     </ul>



     <h3>*Các bước chuyển tiền/chuyển khoản:</h3>
     <p>  - Bước 1 :  Chuyển tiền theo thông tin tài khoản:
       <ul>
         <li>Ngân hàng Vietcombank – TPHCM</li>
         <li>Số tài khoản : 003500078xxxx</li>
         <li> Tên tài khoản : HEAVEN SHOP.</li>

       </ul>
     <br>
       - Bước 2 : Khách hàng thông báo cho cửa (Điện thoại, Email, SMS, …) khi quý khách đã thực hiện chuyển tiền/chuyển khoản. Hoặc liên hệ trực tiếp với bộ phận bán hàng trực tuyến.
       <br>
       - Bước 3 :  Ngay sau khi nhận được thông báo xác nhận từ phía ngân hàng, nhân viên sẽ thông báo lại cho khách hàng đồng thời tiến hành giao hàng cho quý khách.
       <br>
       *Cửa hàng sẽ không chịu trách nhiệm về sai sót trong quá trình chuyển khoản hoặc chuyển khoản sai thông tin. Quý khách phải làm việc trực tiếp với ngân hàng để giải quyết sai sót trên.

   </p>

   <h4>3.    Phương thức thanh toán trực tiếp : đặt hàng và mua hàng tại cửa hàng.</h4>
   <p>  Hệ thống cửa hàng:
     <br>
     - 280 An Dương Vương, P.4,  Q.5: Đt: 028350.8xxxx</p>


</div>
