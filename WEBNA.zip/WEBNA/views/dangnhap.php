

 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                         <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                </div>
            </div>
        </div>
    </div>












<div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Cambria"> Đăng nhập</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row text-center">
            <div class="col-md-6 .col-md-offset-3">


            </div>
        </div>
        <div class="row" >
            <div class="col-md-12 .col-md-offset-3 thongtin">
                <form action="" method="POST" role="form" class="form-signin">
                    <div class="form-group">
                        <div class="form-row">
                            <!-- <div class="col"> -->
                                <br><br>
                                <label>Tên đăng nhập</label>
                                <input type="text" name="txtUsername" class="form-control" placeholder="Nhập tên đăng nhập của bạn" required name="" autofocus="">
                            <!-- </div> -->
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Mật khẩu</label>
                        <input type="password" name="txtPassword" class="form-control" placeholder="Password của bạn" required name="">
                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-private" type="submit" name="submit"><i class="fas fa-sign-in-alt"></i> <span style="color: white">Đăng nhập</span></button>&nbsp;&nbsp;
                        <a href="#" id="forgot_pswd">Forgot password?</a>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-block" type="button" id="btn-signup"><i class="fas fa-user-plus"></i> <a href="?controller=dangki&action=index"><span style="color: white; font-weight: bold">Tạo tài khoản mới</span></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
