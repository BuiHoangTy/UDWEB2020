 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                        <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>










    <div class="slider-area">
        	<!-- Slider -->
			<div class="block-slider block-slider4">
				<ul class="" id="bxslider-home4">
					<li>
						<img src="public/images/slider/cover5.png" alt="Slide">
					</li>
					<li>
                        <img src="public/images/slider/cover1.png" alt="Slide">
					</li>
					<li>
                        <img src="public/images/slider/cover7.jpg" alt="Slide">
					</li>
					<li>
                        <img src="public/images/slider/cover4.png" alt="Slide">
					</li>
          <li>
                        <img src="public/images/slider/cover3.png" alt="Slide">
          </li>
				</ul>
			</div>
			<!-- ./Slider -->
    </div> <!-- End slider area -->

    <div class="promo-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo1">
                        <i class="fas fa-undo"></i>
                          <div class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'doitra') echo 'active'; ?>"><a  href="?controller=doitra&action=index">Đổi trả</a></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo2">
                        <i class="fa fa-truck"></i>
                          <div class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giaohang') echo 'active'; ?>"><a  href="?controller=giaohang&action=index">Miễn phí giao hàng</a></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo3">
                        <i class="fa fa-lock"></i>
                        <div class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'pay') echo 'active'; ?>"><a  href="?controller=pay&action=index">Thanh toán an toàn</a></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo4">
                        <i class="fa fa-gift"></i>
                        <div class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'baohanh') echo 'active'; ?>"><a  href="?controller=baohanh&action=index">Bảo hành sản phảm</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End promo area -->

    <div class="maincontent-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="latest-product">
                        <h2 class="section-title">Sản phẩm mới nhất</h2>
                        <div class="product-carousel" >

                           <!--Cái này bỏ data vô nè more_preoduct</!-->

                           <?php
                                $tmp = new model();
                                $res = $tmp->get_all_table('product');
                                if (mysqli_num_rows($res) > 0) {
                                    // Sử dụng vòng lặp while để lặp kết quả
                                    while($row = mysqli_fetch_assoc($res)) {

                                        $tmp = 'public/images/product/'.$row['Image'];





                                    echo    "<div class='single-product pro'>";
                                    echo        "<div class='product-f-image'>";
                                    echo            "<img src='".$tmp."' alt=''>";
                                    echo            "<div class='product-hover'>";
                                    echo                "<a class='add-to-cart-link addcart' onclick='addtocart({$row['Idproduct']},{$row['Newprice']})'><i class='fa fa-shopping-cart'></i> Thêm vào giỏ hàng</a>";
                                    echo                "<a href='?controller=sanpham&action=detail&id={$row['Idproduct']}' class='view-details-link'><i class='fa fa-link'></i> Xem chi tiết</a>";
                                    echo            "</div>";
                                    echo        "</div>";
                                    echo            "<h2><a href='?controller=sanpham&action=detail&id={$row['Idproduct']}'>".$row['Nameproduct']."</a></h2>";
                                    echo        "<div class='product-carousel-price'>";
                                    echo            "<ins>".number_format($row['Newprice'],0,'.','.').' VNĐ'."</ins>";
                                    echo        "</div>";
                                    echo   "</div>";


                                    }
                                }
                                else {
                                    echo "Không có sản phẩm nào";
                                }
                           ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End main content area -->

    <div class="brands-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="brand-wrapper">
                        <div class="brand-list">
                            <a href="?controller=cuahang&action=converse"><img src="public\images\logo\CONVERSE.png" alt="ok"></a>
                            <a href="?controller=cuahang&action=vans"><img src="public\images\logo\VANS.JPG" alt=""></a>
                            <a href="?controller=cuahang&action=kswiss"><img src="public\images\logo\kswiss.png" alt=""></a>
                            <a href="?controller=cuahang&action=palladium"><img src="public\images\logo\palladium.jpg" alt=""></a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End logo area -->

    <div class="product-widget-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <!-- Bán chạy nhất  -->
                <div class="col-md-4">
                    <div class="single-product-widget" id="best-sell">
                        <!-- Chứa chuỗi best_sell -->
                    </div>
                </div>
                <!-- Kết thúc phần bán chạy nhất -->
                <div class="col-md-4">
                    <div class="single-product-widget" id="view-recently">
                        <!--Chứa chuỗi view_recently-->

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="single-product-widget" id="new-product">
                        <!-- Chứa chuỗi new_product -->
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End product widget area -->


    
