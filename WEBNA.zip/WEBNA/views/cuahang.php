 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>




                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                       <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>
 <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Bookman Old Style"><?php
                            if(!isset($_GET['action']) || ($_GET['action']) == 'page1' || ($_GET['action']) == 'page2') echo "Cửa hàng";
                            else if(($_GET['action'])== 'converse' || ($_GET['action'])== 'CONVERSE') echo "CONVERSE";
                            else if(($_GET['action'])== 'vans' || ($_GET['action'])== 'VANS') echo "VANS";
                            else if(($_GET['action'])== 'kswiss'|| ($_GET['action'])== 'K-SWISS') echo "K-SWISS";
                            else if(($_GET['action'])== 'palladium'|| ($_GET['action'])== 'PALLADIUM') echo "PALLADIUM";
                         ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>



 <div class="hangson">

       <a class="col-xs-2 bana" href="?controller=cuahang&action=converse"
       style="color: white;background-color: rgb(112, 40, 20);text-align: center;border: 1px solid; border-radius:20px">CONVERSE</a>


    <a class="col-xs-2 bana" href="?controller=cuahang&action=vans "
     style="color: white;background-color: rgb(112, 40, 20);text-align: center;border: 1px solid; border-radius:20px">VANS</a>
    <a class="col-xs-2 bana" href="?controller=cuahang&action=kswiss"
     style="color: white;background-color: rgb(112, 40, 20);text-align: center;border: 1px solid; border-radius:20px">K-SWISS</a>
    <a class="col-xs-2 bana" href="?controller=cuahang&action=palladium"
     style="color: white;background-color: rgb(112, 40, 20);text-align: center;border: 1px solid; border-radius:20px">PALLADIUM</a>
 </div>
    <!--Bắt đầu sản phẩm -->
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <!-- Bắt đầu 1 sản phẩm -->







            <!--Include jQuery-->









                <?php
                        while($row = mysqli_fetch_assoc($pro)) {
                                $tmp = 'public/images/product/'.$row['Image'];
                                $tm = number_format($row['Newprice'],0,'.','.').' VNĐ';
                                $t = number_format($row['Oldprice'] + 120000,0,'.','.').' VNĐ';
                                echo    "<div class='col-md-3 col-sm-6'>";
                                echo        "<div class='single-shop-product pro'>";
                                echo            "<div class='product-upper'>";
                                echo                "<a href='?controller=sanpham&action=detail&id={$row['Idproduct']}'><img src='{$tmp}'  draggable='true' ondragstart='drag(event)' alt=''></a>";
                                echo            "</div>";
                                echo           "<h2><a href='?controller=sanpham&action=detail&id={$row['Idproduct']}' >{$row['Nameproduct']}</a></h2>";
                                echo            "<div class='product-carousel-price'>";
                                echo                "<ins>{$tm}</ins> <del>{$t}</del>";
                                echo            "</div>" ;
                                echo            "<div class='product-option-shop'>";
                                echo                "<a onclick='addtocart({$row['Idproduct']},{$row['Newprice']})' class='add_to_cart_button addcart' data-quantity='1' data-product_sku='' data-product_id='70' rel='nofollow')'>Thêm vào giỏ hàng</a>";
                                echo            "</div>";
                                echo        "</div>";
                                echo    "</div>" ;
                        }

                ?>





                <!--Kết thúc 1 sản phẩm -->
            </div>

            <?php
                if($_GET['action'] == 'page1' || $_GET['action'] == 'page2'){
                        echo"    <div class='row'>";
                        echo"        <div class='col-md-12'>";
                        echo"            <div class='product-pagination text-center'>";
                        echo"                <nav>";
                        echo"                 <ul class='pagination'>";
                        echo"                   <li>";
                        echo"                     <a href='?controller=cuahang&action=page1' aria-label='Previous'>";
                        echo"                       <span aria-hidden='true'>&laquo;</span>";
                        echo"                     </a>";
                        echo"                   </li>";
                        echo"                    <li><a href='?controller=cuahang&action=page1' >1</a></li>";
                        echo"                    <li><a href='?controller=cuahang&action=page2' >2</a></li>";
                        echo"                    <li>";
                        echo"                      <a aria-label='Next' href='?controller=cuahang&action=page1'>";
                        echo"                        <span aria-hidden='true'>&raquo;</span>";
                        echo"                      </a>";
                        echo"                    </li>";
                        echo"                  </ul>";
                        echo"               </nav>";
                        echo"            </div>";
                        echo"        </div>";
                        echo"    </div>";
                }


            ?>









        </div>
    </div>
    <!--Kết thúc sản phẩm -->
