 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                       <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>













 <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Bookman Old Style">Liên hệ</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="contact">
      <div class="row">
        <div class="col-md-3 contact-icon">
          <span class="fa fa-home" aria-hidden="true"></span>
        </div>
        <div class="col-md-3 contact-icon">
          <span class="fa fa-envelope" aria-hidden="true"></span>
        </div>
        <div class="col-md-3 contact-icon">
          <span class="fa fa-phone" aria-hidden="true"></span>
        </div>
        <div class="col-md-3 contact-icon">
          <span class="fa fa-fax" aria-hidden="true"></span>
        </div>

      </div>
      <div class="row">
        <div class="col-md-3 contact-text">
          <h4>Địa Chỉ</h4>
          <p>280 An Dương Vương, P4, Q5, TPHCM</p>
        </div>
        <div class="col-md-3 contact-text">
          <h4>Email</h4>
          <p><a href=" ">heaven@gmail.com</a></p>
        </div>
        <div class="col-md-3 contact-text">
          <h4>Số Điện Thoại</h4>
          <p>+0396123456</p>
        </div>
        <div class="col-md-3 contact-text">
          <h4>Fax</h4>
          <p>+0396123456</p>
        </div>
      </div>
      <img src="public/images/na.jpg" alt="">
    </div>
