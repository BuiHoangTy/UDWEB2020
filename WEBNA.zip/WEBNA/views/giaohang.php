<div class="mainmenu-area">
       <div class="container">
           <div class="row">
               <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                       <span class="sr-only">Toggle navigation</span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                   </button>
               </div>
               <div class="navbar-collapse collapse">
                   <ul class="nav navbar-nav">
                       <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                      <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                      <li><div class="shopping-item">
                       <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                   </div></li>

               </div>
           </div>
       </div>
   </div>



   <div class="content">

   <h3>FREE SHIP</h3>
   <h4>Trường hợp được Free Ship:</h4>
   <p>
     <ul>
       <li>các khách hàng đã mua từ 6 đơn hàng trở lên tại Shop </li>
       <li>Địa chỉ giao hàng các quận: Quận 5, Quận 10</li>
       <li>Trong các dịp khuyến mãi của Shop</li>
       <li>Đơn hàng có giá trị > 3.000.000.000đ </li>

     </ul>


   <h4>
     PHÍ GIAO HÀNG
   </h4>
   <ul>
     <li>Nội thành TP Hồ Chí Minh: 30.000đ</li>

     <li>Các tỉnh ngoài khu vực TP Hồ Chí Minh: 50.000/sp</li>



   </ul>


   .</p>


   <p>Mọi vấn đề thắc mắc quý khách vui lòng liên hệ bộ phận chăm sóc khách hàng:
     <br>

   <strong>Văn phòng đại diện: 280 AN DƯƠNG VƯƠNG , phường 4, quận 5, TP.HCM.

   Hotline : 1800.0080 – 02822.666.000</strong>
   .</p>


   </div>
