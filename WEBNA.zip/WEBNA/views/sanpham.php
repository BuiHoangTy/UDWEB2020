 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                        <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>







    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Bookman Old Style">Sản phẩm</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Tìm kiếm</h2>
                        <form action="" method="POST">
                            <input type="text" placeholder="Search products..." id="str_search" onkeyup="search_product()" name="timkiem">
                        </form>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Sản phẩm</h2>
                        <div id="res_search"><!-- Chứa kết quả tìm kiếm --></div>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Sản phẩm mới nhất</h2>
                        <ul id="ganday">
                            <?php
                                if(mysqli_num_rows($ganday) > 0){
                                    while($rowb = mysqli_fetch_assoc($ganday)){
                                        echo "<li><a href='?controller=sanpham&action=detail&id={$rowb['Idproduct']}'>{$rowb['Nameproduct']}</a></li>";
                                    }
                                }
                             ?>
                        </ul>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="product-content-right">
                        <div class="product-breadcroumb">
                            <a href="?controller=trangchu&action=index">Trang chủ</a>
                            <a href="?controller=cuahang&action=<?php echo $hang ?>" id="danhmuc"><?php echo $hang; ?></a>
                            <a href="#" id="ten"><?php echo $row['Nameproduct']  ?></a>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="product-images">
                                    <div class="product-main-img pro" id="hinh9">
                                       <!-- son[i]['diachi'] -->

                                       <?php
                                             $t = 'public/images/product/'.$row['Image'];
                                            echo "<img src='{$t}' alt=''>" ?>
                                    </div>

                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="product-inner">
                                    <h2 class="product-name" id="ten9"><?php echo $row['Nameproduct']   ?></h2>
                                    <div class="product-inner-price" id="gia9">
                                         <?php
                                            $t = number_format($row['Newprice'],0,'.','.').' VNĐ';
                                            $t1 = number_format($row['Oldprice'],0,'.','.').' VNĐ';
                                            echo "<ins>{$t}</ins> <del>{$t1}</del>" ?>

                                    </div>

                                    <form action="" method="POST" class="cart">
                                         <div class="quantity">
                                            <input type="number" size="4" class="input-text qty text" title="Qty" value="<?php if(isset($_SESSION['cart']) && array_key_exists($row['Idproduct'], $_SESSION['cart'])) echo $_SESSION['cart'][$row['Idproduct']]; else echo 1;?>" id="quantity" name="quantity" min="1" step="1">
                                        </div>
                                        <a class="add_to_cart_button addcart" onclick="addtocart(<?php echo $row['Idproduct'].','.$row['Newprice'] ?>)">Thêm vào giỏ hàng</a>
                                    </form>


                                    <div role="tabpanel">
                                        <ul class="product-tab" role="tablist">
                                            <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Mô tả</a></li>
                                            <li role="presentation"><a href="#reviews" aria-controls="reviews" role="tab" data-toggle="tab">Các đánh giá</a></li>
                                            <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Đánh giá</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="home">
                                                <h2>Mô tả sản phẩm</h2>
                                                <p><?php echo $row['Description']      ?></p>

                                            </div>
                                            <div role="tabpanel" class="tab-pane fade" id="reviews">
                                                <?php
                                                    if(mysqli_num_rows($rev) > 0){
                                                        while ($ro = mysqli_fetch_assoc($rev)) {

                                                            echo "<h2 class='Namere'>{$ro['Namereviewer']}</h2>";
                                                            echo "<img class='imgstar' src='public/images/star/{$ro['Star']}sao.PNG' alt=''><br>";
                                                            echo "<input class='inputre' type='text' readonly='' value='{$ro['Review']}'><br><br>";

                                                        }
                                                    }else{
                                                        echo "<p>Chưa có đánh giá nào!</p>";
                                                    }
                                                ?>

                                            </div>
                                            <div role="tabpanel" class="tab-pane fade" id="profile">

                                                <?php
                                                    if(isset($_SESSION['Username'])){
                                                        echo "<form action='' method='post'>";
                                                        echo"<h2>Đánh giá</h2>";
                                                        echo"<div class='submit-review'>";
                                                        echo"<p><label for='name'>Tên</label> <input name='namereview' type='text' value='{$_SESSION['Username']}'></p>";
                                                        echo"<p><label for='email'>Email</label> <input name='emailreview' type='email' value='{$_SESSION['Email']}' ></p>";
                                                        echo"<div class='rating-chooser'>";
                                                        echo"    <p>Xếp hạng</p>";

                                                        echo"<div class='stars'>";
                                                        echo"    <input class='star star-5' id='star-5' type='radio' value='5' name='star'/>";
                                                        echo"    <label class='star star-5' for='star-5'></label>";
                                                        echo"    <input class='star star-4' id='star-4' type='radio' value='4' name='star'/>";
                                                        echo"    <label class='star star-4' for='star-4'></label>";
                                                        echo"    <input class='star star-3' id='star-3' type='radio' value='3' name='star'/>";
                                                        echo"    <label class='star star-3' for='star-3'></label>";
                                                        echo"    <input class='star star-2' id='star-2' type='radio' value='2' name='star'/>";
                                                        echo"    <label class='star star-2' for='star-2'></label>";
                                                        echo"    <input class='star star-1' id='star-1' type='radio' value='1' name='star'/>";
                                                        echo"    <label class='star star-1' for='star-1'></label>";
                                                        echo"</div>";

                                                        echo"</div>";
                                                        echo"<p><label for='review'>Đánh giá của bạn</label> <textarea name='review' id='' cols='30' rows='10'></textarea></p>";
                                                        echo"<p><input type='submit' value='Submit'></p>";
                                                        echo "</form>";
                                                    } else echo "Vui lòng đăng nhập để nhận xét!";
                                                 ?>
                                            </div>


                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>



                        <div class="related-products-wrapper">
                            <h2 class="related-products-title">Sản phẩm liên quan</h2>
                            <div class="related-products-carousel" id="lienquan">


                                 <?php
                                    if(mysqli_num_rows($lienquan) > 0){
                                        while($rowb = mysqli_fetch_assoc($lienquan)){
                                        $tmph = 'public/images/product/'.$rowb['Image'];
                                        $t = number_format($rowb['Newprice'],0,'.','.').' VNĐ';
                                        $tm = number_format($rowb['Oldprice'],0,'.','.').' VNĐ';



                                        echo     "<div class='single-product'>";
                                        echo        "<div class='product-f-image'>";
                                        echo            "<a href='?controller=sanpham&action=detail&id={$rowb['Idproduct']}'><img src='{$tmph}' alt=''></a>";
                                        echo        "</div>";
                                        echo       "<h2><a href='?controller=sanpham&action=detail&id={$rowb['Idproduct']}'>{$rowb['Nameproduct']}</a></h2>";

                                        echo       "<div class='product-carousel-price'>";
                                        echo           "<ins>{$t}</ins> <del>{$tm}</del>";
                                        echo        "</div>";
                                        echo   "</div>";



                                        }
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
