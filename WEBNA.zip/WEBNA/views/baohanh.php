<div class="mainmenu-area">
       <div class="container">
           <div class="row">
               <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                       <span class="sr-only">Toggle navigation</span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                   </button>
               </div>
               <div class="navbar-collapse collapse">
                   <ul class="nav navbar-nav">
                       <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                      <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                      <li><div class="shopping-item">
                       <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                   </div></li>

               </div>
           </div>
       </div>
   </div>

<div class="content">

  <h3>CHÍNH SÁCH BẢO HÀNH TRỌN ĐỜI</h3>
  <p>HEAVEN SHOP luôn nỗ lực mang đến trải nghiệm mua sắm tuyệt vời dành cho phái đẹp từ sự đa dạng sản phẩm, mẫu mã thời thượng, cửa hàng hiện đại, sang trọng và những dịch vụ hậu mãi không ngừng được hoàn thiện. Theo đó, HEAVEN SHOP đã cải tiến và áp dụng Chính sách bảo hành trọn đời dành cho tất cả khách hàng mua sắm tại các cửa hàng HEAVEN SHOP trên toàn quốc và mua online tại HEAVEN SHOP
</p>

<strong>Điều kiện áp dụng:</strong>
<ul>
  <li> Khách hàng vui lòng xuất trình phiếu bảo hành để được áp dụng chính sách bảo hành.</li>

  <li> Sản phẩm được bảo hành miễn phí trong suốt thời gian sử dụng trong các trường hợp sau:</li>
</ul>

<strong>1. Đối với khách hàng mua hàng online</strong>


<p>Quý khách có yêu cầu sửa chữa bảo hành có thể mang sản phẩm tới bất kỳ showroom chính hãng của hệ thống HEAVEN SHOP để sử dụng dịch vụ.
</p>
<p> HEAVEN SHOP chỉ bảo hành đối với các sản phẩm bị hư hỏng về mặt kĩ thuật như hở keo, sứt chỉ.
</p>

<strong>2. Cửa hàng không bảo hành sản phẩm trong các trường hợp sau:
</strong>
<ul>
  <li>Giày dép bị hư do lỗi quý khách gây ra như: trầy xước, mòn đế, nóng chảy, thú vật cắn,...</li>
  <li>Giày dép bị hao mòn tự nhiên trong quá trình sử dụng.
</li>
<li>Các loại đế PU tự hủy qua thời gian sử dụng, sản phẩm bị biến dạng hoặc không có phiếu bảo hành.
</li>
<li>Cửa hàng không nhận sửa chữa những sản phẩm quá cũ (da và đế bị lão hóa, không còn độ bám dính của keo,chỉ hoặc không còn phụ kiện thay thế)
</li>
</ul>
<br>
<p>Khách hàng ở xa vui lòng thanh toán phí vận chuyển khi có nhu cầu bảo hành sản phẩm tại HEAVEN SHOP
</p>


</div>
