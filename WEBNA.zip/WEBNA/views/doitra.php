<div class="mainmenu-area">
       <div class="container">
           <div class="row">
               <div class="navbar-header">
                   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                       <span class="sr-only">Toggle navigation</span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                       <span class="icon-bar"></span>
                   </button>
               </div>
               <div class="navbar-collapse collapse">
                   <ul class="nav navbar-nav">
                       <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                      <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                      <li><div class="shopping-item">
                       <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                   </div></li>

               </div>
           </div>
       </div>
   </div>



   <div class="content">

   <h3>I. Chính sách đổi sản phẩm</h3>
   <h4>Trường hợp đổi hàng:</h4>
   <p>
     <ul>
       <li>  Quý khách được đổi size nếu như sản phẩm được thử không vừa chân.</li>
       <li>HEAVEN SHOP giao nhầm mã, nhầm size, nhầm màu.</li>
       <li>Sản phẩm có lỗi khi không được báo trước.</li>

     </ul>


   <h4>
     Các trường hợp không chấp nhận đổi hàng:
   </h4>
   <ul>
     <li>Sản phẩm không được xác nhận mua từ HEAVEN SHOP.</li>
     <li>Sản phẩm đã được sử dụng hoặc dính bẩn.</li>
     <li>Sản phẩm không được vận hành đúng theo chỉ dẫn, gây hỏng hóc sản phẩm.</li>
     <li>
     Sản phẩm được bán với giá sale từ  30% trở lên</li>

   </ul>


   .</p>
   <h4>Điều kiện đổi hàng:</h4>
   <ul>
     <li>Các sản phẩm mua tại HEAVEN SHOP được áp dụng đổi size trong vòng 7 ngày (kể từ ngày quý khách nhận được hàng, căn cứ vào ngày gửi theo dấu bưu cục)
   </li>
     <li>Trong trường hợp sản phẩm hết size và HEAVEN SHOP hỗ trợ đổi qua sản phẩm khác, sản phẩm đổi phải có giá trị bằng hoặc cao hơn so với giá trị hàng khách đã nhận trước đó. Chúng tôi sẽ không hoàn trả lại số tiền chênh lệch.
   </li>
     <li>Sản phẩm chưa qua sử dụng (không bị dính bẩn)  và còn đủ hộp (còn nguyên vẹn), phụ kiện đi kèm, đủ phiếu bảo hành, và hóa đơn (nếu có).
   </li>
     <li>Khách hàng đến trực tiếp cửa hàng để đổi size, nếu trường hợp ở xa gửi về khách hàng phải chịu phí ship.
   </li>
     <li>Các sản phẩm đều chỉ được đổi 1 lần duy nhất.</li>

   </ul>


   <h4>Quy trình cách thức đổi hàng cho khách hàng:</h4>
   <a href="#"><strong>Bước 1:</strong> Xác nhận tình trạng đổi</a>
   <p>
     Trong vòng 7 ngày kể từ ngày nhận được sản phẩm, nếu sản phẩm thuộc các trường hợp đổi hàng, quý khách phải tiến hành chụp hiện trạng của sản phẩm: Thấy rõ mã hàng, tem, phiếu bảo hành của chúng tôi, chỗ sản phẩm bị lỗi (nếu có). Sau đó liên hệ với bộ phận chăm sóc khách hàng của chúng tôi qua hotline để thông báo thông tin đổi sản phẩm và gửi hình ảnh xác nhận.
   </p>

   <a href="#"><strong>Bước 2:</strong>  Chúng tôi xác nhận</a>

   <p>Chúng tôi sau khi nhận được thông tin sẽ tiến hành xác nhận tình trạng hàng hóa và xác nhận cho khách hàng sản phẩm có được đổi hay không.
   <br>
   Sau khi xác nhận sản phẩm được đổi, quý khách vui lòng giữ hàng hóa trong trạng thái nguyên vẹn  cùng với những phụ kiện và giấy tờ liên quan.
   </p>
   <a href="#"><strong>Bước 3:</strong>  Khách hàng gửi hàng</a>
   <p>Trường hợp ở xa, quý khách gửi lại sản phẩm còn nguyên cùng với các phụ kiện và giấy tờ liên quan, được đóng gói cẩn thận và gửi theo địa chỉ chúng tôi cung cấp.
   <br>
   Trường hợp khách hàng đến cửa hàng đổi trực tiếp, mang theo đầy đủ sản phẩm, phụ kiện và giấy tờ liên quan đến địa chỉ chúng tôi cung cấp sau 15h30.
   </p>

   <a href="#"><strong>Bước 4:</strong>  Chúng tôi xác nhận và gửi hàng cho khách hàng</a>


   <p>
     Sau khi đã nhận, kiểm tra và chấp nhận sản phẩm mà quý khách muốn đổi, chúng tôi sẽ liên hệ để xác nhận đổi hàng và gửi hàng cho quý khách.

   </p>
   <p><strong>Lưu ý:</strong> Nếu sản phẩm gửi về cho chúng tôi không đáp ứng đủ điều kiện đổi đã nêu ở trên hoặc không đủ điều kiện để bán lại, khách hàng phải chịu trách nhiệm chi trả phần thiệt hại cho chúng tôi hoặc được cộng thêm và số tiền mà quý khách phải chi trả cho sản phẩm được đổi.

    </p>

   <h3>II. Chính sách hoàn trả sản phẩm</h3>
   <h4>Trường hợp trả hàng:</h4>
   <p>
     <ul>
       <li>  Sản phẩm được phát hiện lỗi khi không được báo trước.</li>
       <li>
       Sản phẩm không đúng như thông tin trên web, đơn đặt hàng.</li>


     </ul>

   <h4>Các trường hợp không chấp nhận trả hàng:</h4>
   <ul>
     <li>Sản phẩm không được xác nhận mua từ HEAVEN SHOP.</li>
     <li>Sản phẩm đã được sử dụng hoặc dính bẩn.</li>
     <li>Các trường hợp đổi ý, không thích sản phẩm</li>
   </ul>


   .</p>
   <h4>Điều kiện trả hàng</h4>
   <p>Các sản phẩm mua tại HEAVEN SHOP được áp dụng trả trong vòng 3 ngày (kể từ ngày quý khách nhận được hàng, căn cứ vào ngày gửi theo dấu bưu cục)
   Sản phẩm chưa qua sử dụng (không bị dính bẩn)  và còn đủ hộp (còn nguyên vẹn), phụ kiện đi kèm, đủ phiếu bảo hành, và hóa đơn (nếu có).</p>


   <h4>Quy trình cách thức trả hàng cho khách hàng:</h4>

   <a href="#">   <strong>Bước 1: </strong> Xác nhận tình trạng hoàn trả</a>
   <p>Trong vòng 3 ngày kể từ ngày nhận được sản phẩm, quý khách phải tiến hành chụp hiện trạng của sản phẩm: Thấy rõ mã hàng, tem, phiếu bảo hành của chúng tôi, chỗ sản phẩm bị lỗi. Sau đó liên hệ với bộ phận chăm sóc khách hàng của chúng tôi qua hotline để thông báo thông tin đổi sản phẩm và gửi hình ảnh xác nhận.
   </p>
   <a href="#">   <strong>Bước 2: </strong>  Chúng tôi xác nhận</a>
   <p>Chúng tôi sau khi nhận được thông tin sẽ tiến hành xác nhận tình trạng hàng hóa và xác nhận cho khách hàng sản phẩm có được hoàn trả hay không.

   Sau khi xác nhận sản phẩm được trả, quý khách vui lòng giữ hàng hóa trong trạng thái nguyên vẹn  cùng với những phụ kiện và giấy tờ liên quan (phiếu bảo hành, hóa đơn bưu cục..)
   </p>

   <a href="#">   <strong>Bước 3: </strong> Khách hàng gửi hàng</a>

   <p>Trường hợp ở xa, quý khách gửi lại sản phẩm còn nguyên cùng với các phụ kiện và giấy tờ liên quan (phiếu bảo hành, hóa đơn bưu cục..), được đóng gói cẩn thận và gửi theo địa chỉ chúng tôi cung cấp.

   Trường hợp khách hàng đến cửa hàng trực tiếp, mang theo đầy đủ sản phẩm, phụ kiện và giấy tờ liên quan (phiếu bảo hành, hóa đơn..) đến địa chỉ chúng tôi cung cấp sau 15h30.
   </p>

   <a href="#">   <strong>Bước 4: </strong> Chúng tôi xác nhận hoàn tiền cho quý khách</a>

   <p>Sau khi đã nhận, kiểm tra và chấp nhận sản phẩm mà quý khách muốn trả, chúng tôi sẽ liên hệ để xác nhận và thực hiện quá trình hoàn tiền cho quý khách qua tài khoản ngân hàng trong vòng 7-10 ngày.
   </p>





   <h3>II. Chính sách hủy đơn hàng</h3>

   <h4>Trường hợp hủy đơn hàng</h4>
   <ul>
     <li>Đơn hàng sẽ được thông báo hủy nếu như sản phẩm không có sẵn vì bất kỳ lý do nào.</li>
     <li>Đơn hàng sẽ được thông báo hủy khi quý khách có yêu cầu thay đổi thông tin về sản phẩm của đơn hàng (trừ trường hợp đơn hàng đã được xử lý và giao cho đơn vị chuyển phát).</li>
     <li>  Đơn hàng sẽ được phép hủy khi quý khách có yêu cầu hủy đơn hàng trước khi đơn hàng được xử lý giao cho đơn vị vận chuyển.</li>

   </ul>

   <h4>Cam kết khi hủy đơn hàng</h4>
   <ul>
     <li>Trong trường hợp đơn hàng được hủy bởi chúng tôi, chúng tôi sẽ có trách nhiệm thông báo đến quý khách trong thời gian sớm nhất. Quý khách sẽ không phải trả bất kỳ chi phí hủy đơn hàng nào trong trường hợp này.
   </li>
     <li>Trong trường hợp đơn hàng được hủy bởi quý khách, quý khách phải có trách nhiệm thông báo đến chúng tôi trong thời gian sớm nhất. Nếu không, mọi khiếu nại sẽ không được giải quyết khi đơn hàng đã được xử lý.
   </li>

     <li> Nếu quý khách hủy đơn hàng trước khi hàng được vận chuyển, thông thường là trong vòng 1 giờ kể từ lúc nhân viên liên hệ xác nhận đặt hàng, Chúng tôi sẽ hoàn trả 100% tiền cho những quý khách đã thanh toán.
   </li>

     <li>Nếu quý khách hủy đơn hàng sau khi hàng đã được vận chuyển, chúng tôi sẽ giải quyết hoàn tiền cho quý khách sau khi đã trừ các chi phí phát sinh của đơn hàng như: phí vận chuyển...(hoặc chúng tôi sẽ KHÔNG chấp nhận hủy đơn hàng).
   </li>
     <li>Để biết tình trạng hiện tại của đơn hàng, quý khách vui lòng xem trong mục Quản lý đơn hàng trên website hoặc liên hệ bộ phận chăm sóc khách hàng.
   </li>
     <li>Quá thời gian qui định trên, mọi yêu cầu hủy đơn hàng của Quý khách sẽ không được chấp nhận.
   </li>
     <li>Quá thời gian qui định trên, mọi yêu cầu hủy đơn hàng của Quý khách sẽ không được chấp nhận.
   </li>
   <li>Quý khách lưu ý phí dịch vụ cho xử lý giao dịch thẻ với ngân hàng sẽ không hoàn trả một khi đã thanh toán
   </li>
   <p> <strong>Lưu ý:</strong> Mã giảm giá và ưu đãi sẽ không còn hiệu lực cho đơn hàng tiếp theo. Qúy khách vui lòng cân nhắc kỹ trước khi thực hiện hủy đơn hàng.
   </p>
   </ul>


   <h3>II. Chính sách bảo hành :</h3>

   <ul>
     <li>Sản phẩm phải được xác thực là sản phẩm của Hệ thống HEAVEN SHOP (kèm phiếu bảo hành).</li>
     <li>
     Sản phẩm được đem đến đủ hộp, phiếu bảo hành, và sản phẩm phải được vệ sinh lại.</li>
     <li>
     Sản phẩm được bảo hành chính hãng 30 ngày kể từ ngày nhận hàng.</li>
     <li>
     Sản phẩm được HEAVEN SHOP hỗ trợ bảo hành 3 tháng.</li>

   </ul>


   <p> <strong>-Lưu ý:</strong>
     <br>
     <ul>
       <li>   Thời gian xử lý vấn đề bảo hành sau 15H30 mỗi ngày tại tất cả cửa hàng.</li>
       <li>Nếu quý khách tự ý thay đổi, sửa chữa sản phẩm hoặc không tuân theo phương pháp bảo quản dẫn đến sản phẩm bị hư hại. Công ty chúng tôi sẽ hoàn toàn không chịu trách nhiệm về việc bảo hành lỗi sản phẩm trên.
   </li>
       <li>Với các sản phẩm Sale dưới 20% đều được bảo hành chính hãng của công ty phân phối độc quyền tại Việt Nam. Còn lại những sản phẩm Sale trên 20% vẫn nhận được bảo hành của HEAVEN SHOP trong vòng 1 tháng với những lỗi do nhà sản xuất như bung keo, sứt chỉ.
   </li>
       <li>Nhằm mục đích mang đến sự hài lòng cho khách hàng , toàn bộ các sản phẩm bán ra đều hỗ trợ bảo hành sau khi hết bảo hành nếu hệ thống xử lý được. </p>
   </li>

     </ul>





   <p>Mọi vấn đề thắc mắc về đổi – trả – bảo hành và hủy đơn hàng, quý khách vui lòng liên hệ bộ phận chăm sóc khách hàng:
     <br>

   <strong>Văn phòng đại diện: 280 AN DƯƠNG VƯƠNG, phường 4, quận 5, TP.HCM.

   Hotline : 1800.0080 – 02822.666.000</strong>
   .</p>


   </div>
