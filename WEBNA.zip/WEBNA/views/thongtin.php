
 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                       <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>




<div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Cambria"></i> Chỉnh sửa thông tin</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <div class="container">
        <div class="row">

        </div>
        <div class="row">
            <div class="col-md-12 .col-md-offset-50 thongtin">

                <form action="" method="POST">

                    <div class="form-group">
                        <div class="form-row">
                            <br><br>
                            <div class="col">
                                <label>Tên đăng nhập</label>
                                <input type="text" name="tendangnhap" class="form-control" required readonly="" value="<?php echo $user['Username']; ?>">
                            </div>
                        </div>
                    </div>
                     <div class="form-group">
                        <div class="col">
                            <label>Họ và tên</label>
                            <input type="text" name="txtFullname"class="form-control" required  value="<?php echo $user['Name']; ?>">
                             <?php if (isset($error['txtFullname'])): ?>
                                 <p class="text-danger"><?php echo $error['txtFullname'] ?></p>
                              <?php endif ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                            <input type="email" name="txtEmail" class="form-control" required  value="<?php echo $user['Email']; ?>">

                    </div>

                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="txtPhone" class="form-control" required  value="<?php echo $user['Phone']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ</label>
                        <input type="text" name="txtAddress" class="form-control" required value="<?php echo $user['Address']; ?>">
                    </div>
                    <div class="form-group">
                        <div class="col">
                            <label>Ngày sinh</label>
                            <input type="text" name="txtBirthday" class="form-control" required  value="<?php echo $user['Dateofbirth']; ?>">
                        </div>
                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-success" type="submit" name="submit"><span>Cập Nhật<span></button>
                    </div>
                </table>
            </form>
            </div>
        </div>
    </div>
