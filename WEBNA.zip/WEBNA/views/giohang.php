


 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                         <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>

                </div>
            </div>
        </div>
    </div>




















 <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Bookman Old Style">Giỏ hàng</h2>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End Page title area -->


    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Tìm kiếm</h2>
                        <form action="" method="POST">
                            <input type="text" placeholder="Search products..." id="str_search" onkeyup="search_product()" name="timkiem">
                        </form>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Sản phẩm</h2>
                        <div id="res_search"><!-- Chứa kết quả tìm kiếm --></div>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">SẢN PHẨM MỚI NHẤT</h2>
                        <ul id="ganday">
                            <?php
                                if(mysqli_num_rows($lienquan) > 0){
                                    while($rowb = mysqli_fetch_assoc($lienquan)){
                                        echo "<li><a href='?controller=sanpham&action=detail&id={$rowb['Idproduct']}'>{$rowb['Nameproduct']}</a></li>";
                                    }
                                }
                             ?>
                        </ul>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="product-content-right">
                        <div class="woocommerce">
                            <form method="post" action="?controller=thanhtoan&action=index">
                                <table cellspacing="0" class="shop_table cart">
                                    <thead>
                                        <tr>
                                            <th class="product-remove">&nbsp;</th>
                                            <th class="product-thumbnail">&nbsp;</th>
                                            <th class="product-name">Sản phẩm</th>
                                            <th class="product-price">Giá</th>
                                            <th class="product-quantity">Số lượng</th>
                                            <th class="product-subtotal">Tổng cộng</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                                                                <!--Bản sản phẩm -->
                                        <?php
                                        if(isset($_SESSION['cart'])){
                                        require_once 'models/model.php';
                                        foreach ($_SESSION['cart'] as $id => $val) {
                                        $tmp = new model();
                                        $pro = $tmp->get_one_row('product','Idproduct',$id);
                                        if (mysqli_num_rows($pro) > 0){
                                            $row = mysqli_fetch_assoc($pro);
                                             $tmp = 'public/images/product/'.$row['Image'];
                                              $tm = number_format($row['Newprice']*$_SESSION['cart'][$row['Idproduct']],0,'.','.');
                                              $t = number_format($row['Newprice'],0,'.','.');
                                        echo     "<tr class='cart_item'>";
                                        echo            "<td class='product-remove'>";
                                        echo                "<a href='?controller=giohang&action=xoa&id={$row['Idproduct']}&gia={$row['Newprice']}' title='Remove this item' class='remove'>X</a>" ;
                                        echo            "</td>";

                                        echo            "<td class='product-thumbnail'>";
                                        echo                "<a href='?controller=sanpham&action=detail&id={$row['Idproduct']}'><img width='200' height='200' alt='poster_1_up' class='shop_thumbnail' src='{$tmp}'></a>";
                                        echo            "</td>";

                                        echo            "<td class='product-name'>";
                                        echo                "<a style='font-size: 13px' href='?controller=sanpham&action=detail&id={$row['Idproduct']}'>{$row['Nameproduct']}</a>";
                                        echo            "</td>";

                                        echo            "<td class='product-price'>";
                                        echo                "<span class='amount'>{$t} VNĐ</span>";
                                        echo            "</td>";

                                        echo            "<td class='product-quantity'>";
                                        echo                "<div class='quantity buttons_added'>";
                                        echo                    "<input type='button' onclick='Tru({$row['Idproduct']},{$row['Newprice']})' class='minus' value='-'>";
                                        echo                    "<input id='sl{$row['Idproduct']}' name='sl{$row['Idproduct']}' type='number' onchange='Doi({$row['Idproduct']},{$row['Newprice']})'  size='4' class='input-text qty text qatyty's value='{$_SESSION['cart'][$row['Idproduct']]}' min='0' step='1'>";
                                         echo                   "<input type='button' onclick='Cong({$row['Idproduct']},{$row['Newprice']})' class='plus' id= 'plus-btn' value='+'>";
                                         echo               "</div>";
                                        echo            "</td>";



                                        echo            "<td class='product-subtotal'>";
                                        echo                "<input readonly='true' id='tong{$row['Idproduct']}' name='tong{$row['Idproduct']}' class='amount' type='text'  value='{$tm} VNĐ'>";

                                        echo            "</td>";
                                        echo        "</tr>";
                                        }
                                        } }
                                        ?>


                                            <tr>
                                                <td class="actions1" colspan="5">Tổng tiền: </td>

                                                <td><input value="<?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?>" readonly='true' type="text" id="suma" name="summ" style="text-align: center;"></td>

                                            </tr>
                                            <tr>
                                                <td class="actions1" colspan="5">Phí giao hàng: </td>

                                                <td><input type="text" id="ship" name="summ" style="text-align: center;" value="<?php if($_SESSION['ship'] == 0) echo 'Vui lòng chọn nơi giao hàng!'; else echo number_format($_SESSION['ship'],0,'.','.').' VNĐ' ?>"></td>

                                            </tr>


                                            <tr>
                                            <td class="actions" colspan="6">

                                                <input type="submit" value="Thanh toán" name="proceed" class="checkout-button button alt wc-forward">
                                            </td>

                                        <!-- Kết thúc bản sản phẩm -->
                                    </tbody>
                                </table>
                            </form>

                            <div class="cart-collaterals">





                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="public/js/cart.js"></script>
