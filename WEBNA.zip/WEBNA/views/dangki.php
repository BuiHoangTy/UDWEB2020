
 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                        <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>





<div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Cambria"> Đăng kí thành viên</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
        </div>
        <div class="row">
            <div class="col-md-12 .col-md-offset-50 thongtin">

                    <?php
                        if($checkuser)  echo "<p style='color:red;margin: 20px 0 0 0'>Tên đăng nhập đã tồn tại</p>";
                        else if($pass) echo "<p style='color:red; margin: 20px 0 0 0'> Mật khẩu chưa trùng khớp </p>";
                        else if($test) echo "<script>alert(' Đăng kí thành công '); location.href='index.php' </script>";
                    ?>


                <form action="" method="POST">

                    <div class="form-group">
                        <div class="form-row">
                            <br><br>
                            <div class="col">
                                <label>Tên đăng nhập</label>
                                <input type="text" name="username" class="form-control" required value="">
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label>Mật Khẩu</label>
                                <input type="password" name="password" class="form-control" required  value="" >
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <label>Nhập lại mật khẩu</label>
                                <input type="password" name="repassword" class="form-control" required  value="">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                            <input type="email" name="email" class="form-control" required  value="*">

                    </div>
                    <div class="form-group">
                        <div class="col">
                            <label>Họ và tên</label>
                            <input type="text" name="name"class="form-control" required  value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="phone" class="form-control" required  value="">
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ</label>
                        <input type="text" name="address" class="form-control" required value="">
                    </div>
                    <div class="form-group">
                        <div class="col">
                            <label>Ngày sinh</label>
                            <input type="text" name="birthday" class="form-control" required  value="">
                        </div>
                    </div>
                    <div class="form-group" align="center">
                        <button class="btn btn-success" type="submit" name="submit"><span>Đăng kí<span></button>
                    </div>
                </table>
            </form>
            </div>
        </div>
    </div>
