 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>




                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                       <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                       <li><div class="shopping-item">
                        <a href="?controller=giohang&action=index" id='cart'>Giỏ hàng: <span class="cart-amunt"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span> <i class="fa fa-shopping-cart"></i><span class="product-count" id="procount" data-count="0"><?php echo ($_SESSION['sl']); ?></span></a>
                    </div></li>

                </div>
            </div>
        </div>
    </div>
<div class="product-big-title-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="product-bit-title text-center">
                    <h2 style="font-family: Cambria"> Lịch sử đặt hàng </h2>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
        <br><br><br>
        <table id="cart" class="table table-hover table-condensed">
            <h3><?php echo $_SESSION['Username']; ?></h3>
            <hr>
            <thead>
                <tr>
                    <th style="width:50%">Tên sản phẩm</th>
                    <th style="width:10%">Giá</th>
                    <th style="width:8%">Số lượng</th>
                    <th style="width:22%" class="text-center">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
              <?php
                  $sum = 0;
                  if(mysqli_num_rows($res) > 0){
                      while ($row = mysqli_fetch_assoc($res)) {
                          $t = number_format($row['Newprice'],0,'.','.');
                          $tm = number_format($row['Newprice'] * $row['Number'],0,'.','.');
                          $sum+=$row['Newprice'] * $row['Number'];
                          $tmp = 'public/images/product/'.$row['Image'];
                          echo"<tr> ";
                          echo"    <td data-th='Product'> ";
                          echo"        <div class='row'> ";
                          echo"            <div class='col-sm-2 hidden-xs'><img src='{$tmp}' alt='Sản phẩm 1' class='img-responsive' width='100'></div> ";
                          echo"            <div class='col-sm-2 hidden-xs'>";
                          echo"            </div> ";
                          echo"            <div class='col-sm-10'> ";
                          echo"                <h5 class='nomargin'>{$row['Nameproduct']}</h5> ";
                          echo"            </div> ";
                          echo"        </div> ";
                          echo"    </td> ";
                          echo"    <td data-th='Price'>{$t} VNĐ</td> ";
                          echo"    <td><input class='form-control text-center' value='{$row['Number']}' type='number' readonly=''>";
                          echo"    </td> ";
                          echo"    <td data-th='Subtotal' class='text-center'>{$tm} VNĐ</td> ";
                          echo"</tr> ";

                      }
                  } else echo "<h5>Không có đơn hàng nào!</h5>";
               ?>
            <tfoot>
                <tr class="visible-xs">
                    <td class="text-center"><strong>Tổng 200.000 đ</strong>
                    </td>
                </tr>
            <tr>
                <td><a href="index.php" class="btn btn-warning"><i class="fa fa-angle-left"></i> Quay lại trang chủ</a>
                </td>
                <td colspan="2" class="hidden-xs"> <strong>Tổng tiền</strong></td>
                <td class="hidden-xs text-center"><strong><?php echo number_format($sum,0,'.','.').' VNĐ'; ?></strong>
                </td>
            </tr>
    </tfoot>
 </table>
</div>
