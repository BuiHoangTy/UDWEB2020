 <div class="mainmenu-area">
        <div class="container">
            <div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="<?php if(!isset($_GET['controller'])) echo 'active'; else {if($_GET['controller'] == 'trangchu') echo 'active';}; ?>"><a href=".">Trang chủ</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'cuahang') echo 'active'; ?>"><a href="?controller=cuahang&action=page1">Cửa hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'sanpham') echo 'active'; ?>"><a href="?controller=sanpham&action=detail&id=1">Sản phẩm</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'giohang') echo 'active'; ?>"><a href="?controller=giohang&action=index">Giỏ hàng</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'thanhtoan') echo 'active'; ?>"><a href="?controller=thanhtoan&action=index">Thanh toán</a></li>
                        <li class="<?php if(isset($_GET['controller']) && $_GET['controller'] == 'lienhe') echo 'active'; ?>"><a href="?controller=lienhe&action=index">Liên hệ</a></li>
                </div>
            </div>
        </div>
    </div>









<div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2 style="font-family: Bookman Old Style">Thanh toán</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Tìm kiếm</h2>
                        <form action="" method="POST">
                            <input type="text" placeholder="Search products..." id="str_search" onkeyup="search_product()" name="timkiem">
                        </form>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Sản phẩm</h2>
                        <div id="res_search"><!-- Chứa kết quả tìm kiếm --></div>
                    </div>

                    <div class="single-sidebar">
                        <h2 class="sidebar-title">Bài viết gần đây</h2>
                        <ul class="ganday">
                           <?php
                                if(mysqli_num_rows($lienquan) > 0){
                                    while($rowb = mysqli_fetch_assoc($lienquan)){
                                        echo "<li><a href='?controller=sanpham&action=detail&id={$rowb['Idproduct']}'>{$rowb['Nameproduct']}</a></li>";
                                    }
                                }
                             ?>

                        </ul>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="product-content-right">
                        <div class="woocommerce">
                            <div <?php if(isset($_SESSION['Username'])) echo "style='visibility: hidden;'";?>  class="woocommerce-info"><a class="showlogin"  href="?controller=dangnhap&action=index" >Đăng nhập</a>
                            </div>

                           <?php

                                if(isset($_POST['hovaten'])){
                                    if( $_POST['hovaten'] == '' || $_POST['diachi'] == '' ||  $_POST['calc_shipping_country'] == '' ||  $_POST['email'] == '' || $_POST['phone'] == ''){
                                             echo "<script>alert(' Các trường có * là bắt buộc. Vui lòng nhập đầy đủ thông tin.'); </script>";
                                    }
                                    else{
                                         echo "<script>alert(' Thanh toán thành công. '); location.href='index.php' </script>";
                                    }
                                }





                            ?>


                            <form enctype="multipart/form-data" action="" class="checkout" method="post" name="checkout">

                                <div id="customer_details" class="col2-set">
                                    <div class="col-1">
                                        <div class="woocommerce-billing-fields">
                                            <h3>Thông tin khách hàng</h3>


                                            <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                <label class="" for="billing_first_name">Họ và Tên <abbr title="required" class="required">*</abbr>
                                                </label>
                                                <input type="text" value="<?php if(isset($row['Name'])) echo $row['Name'] ?>" placeholder="" id="billing_first_name" name="hovaten" class="input-text ">
                                            </p>


                                            <div class="clear"></div>


                                            <p id="billing_city_field" class="form-row form-row-wide address-field validate-required" data-o_class="form-row form-row-wide address-field validate-required">
                                                <label class="" for="billing_city">Tỉnh / Thành phố <abbr title="required" class="required">*</abbr>
                                                </label>
                                                 <p class="form-row form-row-wide">
                                                <select rel="calc_shipping_state" class="country_to_state" id="shipping" name="calc_shipping_country" onchange="ship()">
                                                    <option value="">Tỉnh/Thành phố...</option>
                                                    <option value="AG">An Giang</option>
                                                    <option value="BRVT">Bà Rịa - Vũng Tàu</option>
                                                    <option value="BK">Bắc Kạn</option>
                                                    <option value="BG">Bắc Giang</option>
                                                    <option value="BL">Bạc Liêu</option>
                                                    <option value="BN">Bắc Ninh</option>
                                                    <option value="BT">Bến Tre</option>
                                                    <option value="BD">Bình Dương</option>
                                                    <option value="BDD">Bình Định</option>
                                                    <option value="BP">Bình Phước</option>
                                                    <option value="BT">Bình Thuận</option>
                                                    <option value="CM">Cà Mau</option>
                                                    <option value="CT">Cần Thơ</option>
                                                    <option value="CB">Cao Bằng</option>
                                                    <option value="DDN">Đà Nẵng</option>
                                                    <option value="DDL">Đắk Lắk</option>
                                                    <option value="DDN">Đắk Nông</option>
                                                    <option value="DDB">Điện Biên</option>
                                                    <option value="DDN">Đồng Nai</option>
                                                    <option value="DDT">Đồng Tháp</option>
                                                    <option value="GL">Gia Lai</option>
                                                    <option value="HG">Hà Giang</option>
                                                    <option value="HNAM">Hà Nam</option>
                                                    <option value="HNOI">Hà Nội</option>
                                                    <option value="HT">Hà Tĩnh</option>
                                                    <option value="HD">Hải Dương</option>
                                                    <option value="HP">Hải Phòng</option>
                                                    <option value="HG">Hậu Giang</option>
                                                    <option value="TPHCM">TP. Hồ Chí Minh</option>
                                                    <option value="HB">Hòa Bình</option>
                                                    <option value="HY">Hưng Yên</option>
                                                    <option value="KH">Khánh Hòa</option>
                                                    <option value="KG">Kiên Giang</option>
                                                    <option value="KT">Kon Tum</option>
                                                    <option value="LC">Lai Châu</option>
                                                    <option value="LDD">Lâm Đồng</option>
                                                    <option value="LS">Lạng Sơn</option>
                                                    <option value="LC">Lào Cai</option>
                                                    <option value="LA">Long An</option>
                                                    <option value="NDD">Nam Định</option>
                                                    <option value="NA">Nghệ An</option>
                                                    <option value="NB">Ninh Bình</option>
                                                    <option value="NT">Ninh Thuận</option>
                                                    <option value="PT">Phú Thọ</option>
                                                    <option value="PY">Phú Yên</option>
                                                    <option value="QB">Quảng Bình</option>
                                                    <option value="QNAM">Quảng Nam</option>
                                                    <option value="QNGAI">Quảng Ngãi</option>
                                                    <option value="QNINH">Quảng Ninh</option>
                                                    <option value="QTRI">Quảng Trị</option>
                                                    <option value="ST">Sóc Trăng</option>
                                                    <option value="SL">Sơn La</option>
                                                    <option value="TN">Tây Ninh</option>
                                                    <option value="TB">Thái Bình</option>
                                                    <option value="TN">Thái Nguyên</option>
                                                    <option value="TH">Thanh Hóa</option>
                                                    <option value="TTH">Thừa Thiên Huế</option>
                                                    <option value="TG">Tiền Giang</option>
                                                    <option value="TV">Trà Vinh</option>
                                                    <option value="TQ">Tuyên Quang</option>
                                                    <option value="VL">Vĩnh Long</option>
                                                    <option value="VP">Vĩnh Phúc</option>
                                                    <option value="YB">Yên Bái</option>
                                                </select>
                                                </p>
                                            </p>

                                            <p id="billing_state_field" class="form-row form-row-first address-field validate-state" data-o_class="form-row form-row-first address-field validate-state">
                                                <label class="" for="billing_state">Quận / Huyện <abbr title="required" class="required">*</abbr></label>
                                                <input type="text" id="billing_state" name="quan" placeholder="Quận / Huyện..." value="" class="input-text">
                                            </p>

                                            <p id="billing_address_1_field" class="form-row form-row-wide address-field validate-required">
                                                <label class="" for="billing_address_1">Địa chỉ <abbr title="required" class="required">*</abbr>
                                                </label>
                                                <input type="text" value="<?php if(isset($row['Address'])) echo $row['Address'] ?>" placeholder="Tên đường" id="billing_address_1" name="diachi" class="input-text ">
                                            </p>


                                            <div class="clear"></div>

                                            <p id="billing_email_field" class="form-row form-row-first validate-required validate-email">
                                                <label class="" for="billing_email">Địa chỉ Email <abbr title="required" class="required">*</abbr>
                                                </label>
                                                <input type="text" value="<?php if(isset($row['Email'])) echo $row['Email'] ?>" placeholder="" id="email" name="email" class="input-text ">
                                            </p>

                                            <p id="billing_phone_field" class="form-row form-row-last validate-required validate-phone">
                                                <label class="" for="billing_phone">Điện thoại <abbr title="required" class="required">*</abbr>
                                                </label>
                                                <input type="text" value="<?php if(isset($row['Phone'])) echo $row['Phone'] ?>" placeholder="" id="phone" name="phone" class="input-text ">
                                            </p>
                                            <div class="clear"></div>



                                        </div>
                                    </div>

                                    <div class="col-2">
                                        <div class="woocommerce-shipping-fields">
                                            <h3 id="ship-to-different-address">




                                        </div>

                                    </div>

                                </div>

                                <h3 id="order_review_heading">Đơn đặt hàng của bạn</h3>

                                <div id="order_review" style="position: relative;">
                                    <table class="shop_table">
                                        <thead>
                                            <tr>
                                                <th class="product-name">Sản phẩm</th>
                                                <th class="product-total">Tổng cộng</th>
                                            </tr>
                                        </thead>
                                        <tbody class='thanhtoan'>
                                             <?php
                                                require_once 'models/model.php';
                                                if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])){
                                                    $tmp = new model();
                                                    foreach ($_SESSION['cart'] as $key => $value) {


                                                         $res = $tmp->get_one_row('product','Idproduct',$key);

                                                        if ($res) {
                                                            if(mysqli_num_rows($res) > 0){
                                                                $row = mysqli_fetch_assoc($res);
                                                                $tm = number_format($_SESSION['cart'][$key]*$row['Newprice'],0,'.','.').' VNĐ';
                                                                echo    "<tr class='cart_item'>";
                                                                echo        "<td class='product-name'>
                                                                            {$row['Nameproduct']} <strong class='product-quantity'>× {$_SESSION['cart'][$key]}</strong> </td>";
                                                                echo    "<td class='product-total'>  <span class='amount'>{$tm}</span> </td>";

                                                            }
                                                         }
                                                    }

                                                }

                                                //var_dump($num);
                                                //var_dump($_SESSION['ship']);
                                             ?>
                                            <!-- <tr class="cart_item">
                                                <td class="product-name">
                                                    Ship Your Idea <strong class="product-quantity">× 1</strong> </td>
                                                <td class="product-total">
                                                    <span class="amount">£15.00</span> </td>
                                            </tr> -->
                                        </tbody>
                                        <tfoot>

                                            <tr class="cart-subtotal">
                                                <th>Tổng tiền</th>
                                                <td><span class="amount tong"><?php echo number_format($_SESSION['tong'],0,'.','.').' VNĐ'; ?></span>
                                                </td>
                                            </tr>

                                            <tr class="shipping">
                                                <th>Giao hàng và xử lý</th>
                                                <td class="ship" id="ship">
                                                    <?php if(!isset($_SESSION['ship'])||$_SESSION['ship']==0 ) echo 'Vui lòng chọn nơi giao hàng!'; else echo number_format($_SESSION['ship'],0,'.','.').' VNĐ'; ?>
                                                    <input type="hidden" class="shipping_method" value="free_shipping" id="shipping_method_0" data-index="0" name="shipping_method[0]">
                                                </td>
                                            </tr>


                                            <tr class="order-total">
                                                <th>Tổng đơn hàng</th>
                                                <td><strong><span class="amount tongship"><?php if(isset($_SESSION['ship'])) { $t = $_SESSION['tong'] + $_SESSION['ship']; echo number_format($t,0,'.','.').' VNĐ';} ?></span></strong> </td>
                                            </tr>

                                        </tfoot>
                                    </table>


                                    <div id="payment">
                                        <ul class="payment_methods methods">
                                            <li class="payment_method_bacs">
                                                <input type="radio" data-order_button_text="" checked="checked" value="bacs" name="payment_method" class="input-radio" id="payment_method_bacs">
                                                <label for="payment_method_bacs">Chuyển tiền trực tiếp qua ngân hàng </label>
                                                <div class="payment_box payment_method_bacs">
                                                    <p>Thanh toán trực tiếp vào tài khoản ngân hàng của chúng tôi. Vui lòng sử dụng ID đơn hàng của bạn làm tài liệu tham khảo thanh toán. Đơn hàng của bạn đã thắng được vận chuyển cho đến khi tiền được xóa trong tài khoản của chúng tôi.</p>
                                                </div>
                                            </li>
                                            <li class="payment_method_cheque">
                                                <input type="radio" data-order_button_text="" value="cheque" name="payment_method" class="input-radio" id="payment_method_cheque">
                                                <label for="payment_method_cheque">Thanh toán bằng Séc </label>
                                                <div style="display:none;" class="payment_box payment_method_cheque">
                                                    <p>Vui lòng gửi séc của bạn đến Tên cửa hàng, tên đường, tỉnh, bang/quận, mã bưu điện.</p>
                                                </div>
                                            </li>
                                            <li class="payment_method_paypal">
                                                <input type="radio" data-order_button_text="Proceed to PayPal" value="paypal" name="payment_method" class="input-radio" id="payment_method_paypal">
                                                <label for="payment_method_paypal">PayPal <img alt="PayPal Acceptance Mark" src="https://www.paypalobjects.com/webstatic/mktg/Logo/AM_mc_vs_ms_ae_UK.png"><a title="What is PayPal?" onclick="javascript:window.open('https://www.paypal.com/gb/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;" class="about_paypal" href="https://www.paypal.com/gb/webapps/mpp/paypal-popup">PayPal là gì?</a>
                                                </label>
                                                <div style="display:none;" class="payment_box payment_method_paypal">
                                                    <p>
Thanh toán qua PayPal; bạn có thể thanh toán bằng thẻ tín dụng nếu bạn không có tài khoản PayPal.</p>
                                                </div>
                                            </li>
                                        </ul>

                                        <div class="form-row place-order">


                                            <input type="submit" name="" class="add_to_cart_button" value="Thanh toán">

                                        </div>

                                        <div class="clear"></div>

                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
