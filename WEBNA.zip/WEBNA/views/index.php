<?php session_start();
    if(!isset($_SESSION['tong'])) $_SESSION['tong'] = 0;
    if(!isset($_SESSION['sl'])) $_SESSION['sl'] = 0;
    if(!isset($_SESSION['cart'])) $_SESSION['cart'] = array();
    if(!isset($_SESSION['ship'])) $_SESSION['ship'] = 0;
?>

<!DOCTYPE html>
<!--
	ustora by freshdesignweb.com
	Twitter: https://twitter.com/freshdesignweb
	URL: https://www.freshdesignweb.com/ustora/
-->
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trang chủ</title>

    <style media="screen">
    .py-5 {
    padding-top: 3rem !important;
      padding-bottom: 3rem !important;
  }
  .py-3 {
    padding-top: 1rem !important;
      padding-bottom: 1rem !important;
  }
  .text-capitalize {
    text-transform: capitalize !important;
  }

  .w3_agileits-team1 h5 {
      font-size: 20px;
      color: #000;
    text-transform: uppercase;
      letter-spacing: 1px;
       font-weight: bold;
      letter-spacing: 3px;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  }
  .w3_agileits-team1 p {
      margin: 0;
      font-size: 15px;
      color: #777;
      line-height: 28px;
      font-weight: 600;
      letter-spacing: 1px;
  }
  .social-icons ul li {
      display: inline-block;
      text-align: center;
  }

  .social-icons ul li  {
        font-size: 12px;
      color: #fff;
      background: #333;
      width: 37px;
      height: 37px;
      line-height: 37px;
      border-radius: 50%;
  }

  .text-capitalize{
    font-size: 35px;
    color: #000;
  text-transform: uppercase;
    letter-spacing: 1px;
     font-weight: bold;
    letter-spacing: 3px;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    padding-bottom: 50px;
    text-align: center;

  }

  .social-icons ul li a.fab:hover {
      color: #fff;
      background: #3F51B5;
  }

  .team-right p {
      font-size: 20px;
  }
  .img-fluid {
    max-width: 100%;
    height: 200px;
  }

  .mt-3,
  .my-3 {
    margin-top: 1rem !important;
  }
  .mr-1,
  .mx-1 {
    margin-right: 0.25rem !important;
  }

  .mt-2,
  .my-2 {
    margin-top: 0.5rem !important;
  }
  .mb-1,
  .my-1 {
    margin-bottom: 0.25rem !important;
  }

  .ml-1,
  .mx-1 {
    margin-left: 0.25rem !important;
  }

    </style>
    <script defer src="https://use.fontawesome.com/releases/v5.7.2/js/all.js" integrity="sha384-0pzryjIRos8mFBWMzSSZApWtPl/5++eIfzYmTgBBmXYdhvxPc+XcFEk+zJwDgWbP" crossorigin="anonymous"></script>


    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,200,300,700,600' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="public/css/font-awesome.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="public/css/owl.carousel.css">
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/responsive.css">

    <!--Javascript-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

    <div class="header-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="user-menu">
                        <ul>
                            <li><p> <?php if(isset($_SESSION['Username'])){
                            echo"   <div class='dropdown'>";
                            echo"       <a class='angry'><i class='fa fa-user'></i>  Xin chào {$_SESSION['Username']}</a>";
                            echo"       <div class='dropdown-content'>";
                            echo"           <a class='userhover' href='?controller=thongtin&action=index'>Sửa thông tin</a>";
                            echo"           <a class='userhover' href='?controller=lichsu&action=index' >Lịch sử đặt hàng</a>";
                                          if($_SESSION['Type']==1){
                              echo"           <a class='userhover' href='/WEBNA/au_admin/admin/index.php' >Quản lý</a>";}
                            echo"        </div>";
                            echo"    </div>";


                            } else echo "<a href='#'><i class='fa fa-user'></i> Tài khoản của tôi</a>";?></p></li>

                            <li><a href="?controller=giohang&action=index"><i class="fa fa-user"></i> Giỏ hàng của tôi</a></li>
                            <li <?php if(isset($_SESSION['Username'])) echo "style='visibility: hidden'"; ?> ><a href="?controller=dangnhap&action=index"><i class="fa fa-user"></i> Đăng nhập</a></li>
                            <li <?php if(isset($_SESSION['Username'])) echo "style='visibility: hidden'"; ?>><a href="?controller=dangki&action=index"><i class="fa fa-user"></i> Đăng kí</a></li>
                            <li><a href="?controller=trangchu&action=index1"><i class="fa fa-user"></i> Đăng xuất </a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div> <!-- End header area -->



    <!-- End mainmenu area -->











    <?php
            include_once 'routes.php';
    ?>







    <!-- Footer -->
    <div class="footer-top-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="footer-about-us">
                        <h2><span>HEAVEN</span> SHOP</h2>
                        <p style="text-align: justify;">HEAVEN SHOP là Shop  được xây dựng bởi những con người đáng yêu và dễ thương nhất quả đất! Cung cấp phân phối các hãng giày thời trang đi đầu thời đại hiện nay, phù hợp với mọi lứa tuổi. </p>
                        <div class="footer-social">
                            <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">Điều hướng người dùng </h2>
                        <ul>
                            <li><a href="<?php if(isset($_SESSION['Username'])) echo '?controller=thongtin&action=index'?>">Tài khoản của tôi</a></li>

                            <li><a href="#" class="bumm">
                                <div class="dropdown">
                                    <p class="angry">Liên hệ nhà cung cấp</p>
                                    <div class="dropdown-content">
                                        <a href="https://www.converse.com/" target="_blank">CONVERSE</a>
                                        <a href="http://vans.com/" target="_blank">VANS</a>
                                        <a href="http://kswiss.com/" target="_blank">K-SWISS</a>
                                        <a href="https://palladiumboots.com/" target="_blank">PALLADIUM</a>
                                    </div>
                                </div>
                        </a></li>
                            <li><a href="?controller=trangchu&action=index">Trang đầu</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">Các danh mục</h2>
                        <ul>
                            <li><a href="?controller=cuahang&action=converse">CONVERSE</a></li>
                            <li><a href="?controller=cuahang&action=vans">VANS</a></li>
                            <li><a href="?controller=cuahang&action=kswiss">K-SWISS</a></li>
                            <li><a href="?controller=cuahang&action=palladium">PALLADIUM</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6">
                    <div class="footer-newsletter">
                        <h2 class="footer-wid-title">Bản tin</h2>
                        <p style="text-align: justify;">Đăng ký nhận bản tin của chúng tôi và nhận các ưu đãi độc quyền mà bạn sẽ không tìm thấy ở bất cứ nơi nào khác trực tiếp đến hộp thư đến của bạn!</p>
                        <div class="newsletter-form">
                            <form action="#">
                                <input type="email" placeholder="Nhập email của bạn">
                                <input type="button" value="Đăng ký" onclick="myFunction()">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Tạo thông báo nhận email-->
        <script>
            function myFunction() {
                alert("Bạn đã đăng ký thành công!");
            }
        </script>
    </div> <!-- End footer top area -->

    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                        <p>&copy;  2020 - Bản quyền của những Người bạn Team HEAVEN - <a href="Heaven.com" target="_blank">heaven.com</a></p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="footer-card-icon">
                        <i class="fab fa-cc-discover"></i>
                        <i class="fab fa-cc-mastercard"></i>
                        <i class="fab fa-cc-paypal"></i>
                        <i class="fab fa-cc-visa"></i>
                    </div>
                </div>
            </div>
        </div>
    </div> End footer bottom area

    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>

    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

    <!-- jQuery sticky menu -->
    <script src="public/js/owl.carousel.min.js"></script>
    <script src="public/js/jquery.sticky.js"></script>

    <!-- jQuery easing -->
    <script src="public/js/jquery.easing.1.3.min.js"></script>

    <!-- Main Script -->
    <script src="public/js/main.js"></script>

    <!-- Slider -->
    <script type="text/javascript" src="public/js/bxslider.min.js"></script>
	<script type="text/javascript" src="public/js/script.slider.js"></script>
    <!-- Js Thinh</!-->
    <script type="text/javascript" src="public/js/data.js"></script>
    <script type="text/javascript" src="public/js/cart.js"></script>


  </body>
</html>
