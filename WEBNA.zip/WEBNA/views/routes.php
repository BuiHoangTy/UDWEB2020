<?php
require_once 'index.php';
require_once 'controllers/'.$controller.'.php';

switch ($controller) {
	case 'trangchu':
		$controller = new trangchu();
		break;
	case 'sanpham':
		$controller = new sanpham();
		break;
	case 'cuahang':
		$controller = new cuahang();
		break;
	case 'giohang':
		$controller = new giohang();
		break;
	case 'thanhtoan':
		$controller = new thanhtoan();
		break;
	case 'dangnhap':
		$controller = new dangnhap();
		break;
	case 'dangki':
		$controller = new dangki();
		break;
	case 'lienhe':
		$controller = new lienhe();
		break;
	case 'doitra':
		$controller = new doitra();
		break;
	case 'giaohang':
		$controller = new giaohang();
		break;
	case 'pay':
		$controller = new pay();
		break;
		case 'baohanh':
			$controller = new baohanh();
			break;
	case 'thongtin':
		$controller = new thongtin();
		break;
		case 'lichsu':
		$controller = new lichsu();
		break;
}
$controller->{$action}();



?>
