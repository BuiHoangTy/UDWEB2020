<?php
		
		if(isset($_GET["controller"], $_GET["action"])){
			$controller = ($_GET["controller"]);
			$action = ($_GET["action"]);
		} else
		{
			$controller = "trangchu";
			$action = "index";
		}
		
		require_once 'controllers/'.$controller.'.php';
?>